import json

import pytest
from pydantic import BaseModel

from transports import (
    Client,
    Server,
    Session,
    cbor_to_json,
    decode_as,
    diff,
    encode,
    encode_as,
    json_to_cbor,
    json_to_msgpack,
    msgpack_to_json,
    protocol,
    register_codec,
    registered_codecs,
    unregister_codec,
)

MODEL = json.dumps({"Map": {"name": {"Str": "lamp"}, "on": {"Bool": True}, "count": {"Int": 123456}}})


def test_msgpack_round_trip():
    blob = encode_as(MODEL, "application/msgpack")
    assert isinstance(blob, bytes)
    assert json.loads(decode_as(blob, "application/msgpack")) == json.loads(MODEL)


def test_msgpack_is_smaller_than_json():
    assert len(encode_as(MODEL, "application/msgpack")) < len(encode(MODEL))


def test_json_via_encode_as_matches_encode():
    assert encode_as(MODEL, "application/json") == encode(MODEL)


def test_encodings_and_diff_match_golden_vectors():
    """Byte-identity across build targets: these exact bytes must come out of the native wheel, the
    Pyodide (emscripten) wheel, and the wasm-bindgen JS binding alike — the vectors were produced by
    the native build, and this test runs unchanged on the others."""
    assert encode_as(MODEL, "application/msgpack").hex() == (
        "81a34d617083a5636f756e7481a3496e74ce0001e240a46e616d6581a3537472a46c616d70a26f6e81a4426f6f6cc3"
    )
    assert encode_as(MODEL, "application/cbor").hex() == (
        "a1634d6170a365636f756e74a163496e741a0001e240646e616d65a163537472646c616d70626f6ea164426f6f6cf5"
    )
    old = json.dumps({"Map": {"name": {"Str": "lamp"}, "tags": {"List": [{"Int": 1}, {"Int": 2}]}}})
    new = json.dumps({"Map": {"name": {"Str": "beacon"}, "tags": {"List": [{"Int": 1}]}}})
    assert json.loads(diff(old, new)) == {
        "rev": 0,
        "ops": [
            {"Set": {"path": [{"Key": "name"}], "value": {"Str": "beacon"}}},
            {"RemoveAt": {"path": [{"Key": "tags"}], "index": 1}},
        ],
    }
    wire = json.dumps({"t": "patch", "id": 7, "patch": {"rev": 2, "ops": []}})
    assert json_to_msgpack(wire).hex() == "83a2696407a5706174636882a36f707390a372657602a174a57061746368"


def test_unknown_codec_raises():
    with pytest.raises(ValueError):
        encode_as(MODEL, "application/protobuf")


MSG = json.dumps({"t": "patch", "id": 7, "patch": {"rev": 2, "ops": []}})


def test_json_msgpack_message_round_trip():
    blob = json_to_msgpack(MSG)
    assert isinstance(blob, bytes)
    assert json.loads(msgpack_to_json(blob)) == json.loads(MSG)


def test_protocol_encode_decode_json():
    wire = protocol.encode(MSG, protocol.JSON)
    assert isinstance(wire, str)
    assert protocol.decode(wire) == json.loads(MSG)


def test_protocol_encode_decode_msgpack():
    wire = protocol.encode(MSG, protocol.MSGPACK)
    assert isinstance(wire, bytes)
    assert protocol.decode(wire) == json.loads(MSG)


def test_cbor_round_trip():
    blob = encode_as(MODEL, "application/cbor")
    assert isinstance(blob, bytes)
    assert json.loads(decode_as(blob, "application/cbor")) == json.loads(MODEL)


def test_cbor_is_smaller_than_json():
    assert len(encode_as(MODEL, "application/cbor")) < len(encode(MODEL))


def test_json_cbor_message_round_trip():
    blob = json_to_cbor(MSG)
    assert isinstance(blob, bytes)
    assert json.loads(cbor_to_json(blob)) == json.loads(MSG)


def test_protocol_encode_decode_cbor():
    wire = protocol.encode(MSG, protocol.CBOR)
    assert isinstance(wire, bytes)
    assert protocol.decode(wire, protocol.CBOR) == json.loads(MSG)


def test_normalize_codec_aliases():
    assert protocol.normalize_codec("application/msgpack") == protocol.MSGPACK
    assert protocol.normalize_codec("application/cbor") == protocol.CBOR
    assert protocol.normalize_codec(None) == protocol.JSON
    with pytest.raises(ValueError):
        protocol.normalize_codec("application/protobuf")


CUSTOM = "application/x-test"


def _enc(obj):  # toy custom *binary* codec: a 1-byte marker + utf-8 JSON
    return b"X" + json.dumps(obj).encode()


def _dec(data):
    return json.loads(bytes(data)[1:])


class _Device(BaseModel):
    name: str
    on: bool = False


@pytest.fixture
def custom_codec():
    register_codec(CUSTOM, _enc, _dec)
    yield CUSTOM
    unregister_codec(CUSTOM)


def test_register_and_normalize(custom_codec):
    assert CUSTOM in registered_codecs()
    assert protocol.normalize_codec(CUSTOM) == CUSTOM


def test_cannot_override_builtin():
    with pytest.raises(ValueError):
        register_codec("application/json", _enc, _dec)


def test_unregister_makes_codec_unknown():
    register_codec(CUSTOM, _enc, _dec)
    unregister_codec(CUSTOM)
    assert CUSTOM not in registered_codecs()
    with pytest.raises(ValueError):
        protocol.normalize_codec(CUSTOM)


def test_custom_codec_protocol_round_trip(custom_codec):
    wire = protocol.encode(MSG, custom_codec)
    assert isinstance(wire, bytes) and wire[:1] == b"X"
    assert protocol.decode(wire, custom_codec) == json.loads(MSG)


def test_custom_codec_via_encode_as(custom_codec):
    blob = encode_as(MODEL, custom_codec)
    assert isinstance(blob, bytes)
    assert json.loads(decode_as(blob, custom_codec)) == json.loads(MODEL)


def test_custom_codec_end_to_end_over_server(custom_codec):
    session = Session()
    server = Server(session)
    d = _Device(name="lamp")
    mid = session.host(d)
    client = Client(codec=custom_codec)

    for m in server.open("c", codec=custom_codec):
        assert isinstance(m, bytes)  # our codec frames as binary
        client.recv(m)
    assert client.model(mid, _Device) == d

    d.on = True
    for m in server.flush()["c"]:
        client.recv(m)
    assert client.model(mid, _Device).on is True
