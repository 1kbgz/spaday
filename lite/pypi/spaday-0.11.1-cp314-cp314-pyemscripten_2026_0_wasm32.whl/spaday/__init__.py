from . import actions
from .actions import (
    ActionSequence,
    CallEndpoint,
    Download,
    Emit,
    If,
    Invoke,
    NamedJs,
    RefreshTree,
    SendPatch,
    Sequence,
    SetField,
    SetProp,
    SetStorage,
    Toggle,
    ToggleField,
    all_,
    any_,
    arr,
    bind,
    by_id,
    call,
    close_modal,
    close_popup,
    concat,
    cond,
    eq,
    event_closest,
    event_prop,
    event_value,
    field,
    item,
    lit,
    not_,
    obj,
    open_modal,
    open_popup,
    prop,
    scope,
    this,
)
from .bootstrap import Js, Wire
from .catalog import ComponentSchema, PropertyKind, PropertySchema
from .cem import classes, generate
from .component import Component, Paragraph, Strong, Text, element
from .conformance import check_script
from .packages import ComponentPackage, discover_component_package_names, discover_component_packages, resolve_component_packages
from .render import render_html
from .spaday import apply, decode_frame, diff, encode_frame, parse_cem  # compiled Rust extension (rust/python)
from .theme import SHELL_TOKENS, Token
from .ui import (
    Alert,
    Button,
    Checkbox,
    DateInput,
    Design,
    Dialog,
    NumberInput,
    Progress,
    RadioGroup,
    Select,
    Slider,
    Switch as ToggleSwitch,
    TextArea,
    TextInput,
)
from .validate import ValidationError, validate
from .worker import WorkerApp

__version__ = "0.11.1"

__all__ = [
    "check_script",
    # theming token reference (css custom properties are set via Component.css)
    "SHELL_TOKENS",
    "Token",
    "CallEndpoint",
    "Download",
    "Component",
    # external component-package assets (direct descriptor, Python path, or entry point)
    "ComponentPackage",
    "ComponentSchema",
    "Emit",
    "If",
    "Invoke",
    "NamedJs",
    "RefreshTree",
    "Paragraph",
    "PropertyKind",
    "PropertySchema",
    "SendPatch",
    "Sequence",
    "ActionSequence",
    "SetField",
    "SetProp",
    "SetStorage",
    "Strong",
    "Text",
    "Toggle",
    # generic controls (spaday.ui) — ToggleSwitch is spaday.ui.Switch, beside the shell's Switch router
    "Alert",
    "Button",
    "Checkbox",
    "DateInput",
    "Design",
    "Dialog",
    "NumberInput",
    "Progress",
    "RadioGroup",
    "Select",
    "Slider",
    "TextArea",
    "TextInput",
    "ToggleSwitch",
    "ToggleField",
    "ValidationError",
    "WorkerApp",
    # anywidget host (optional; requires the `widget` extra)
    "Widget",
    # a typed transports wire spec for a multi-model page (serve/bootstrap wire=[…])
    "Wire",
    "__version__",
    # action DSL (declarative behavior, run in the browser)
    "actions",
    "all_",
    "any_",
    "apply",
    "arr",
    "bind",
    "by_id",
    "call",
    "close_modal",
    "close_popup",
    "classes",
    "concat",
    "cond",
    "decode_frame",
    # component-tree diff/patch (compiled core)
    "diff",
    "discover_component_packages",
    "discover_component_package_names",
    "element",
    # framed wire (tree/patch over transports' Frame + JSON/msgpack codecs)
    "encode_frame",
    "eq",
    "event_closest",
    "event_prop",
    "event_value",
    "field",
    "item",
    "generate",
    "lit",
    "not_",
    "open_modal",
    "open_popup",
    "obj",
    # CEM binding generator
    "parse_cem",
    "prop",
    "scope",
    # server-side rendering (light-DOM HTML for first paint; client hydrates)
    "render_html",
    "resolve_component_packages",
    "this",
    # build-time validation
    "validate",
]


def __getattr__(name: str):
    # `Widget` pulls in anywidget (an optional dep), so load it lazily — `import spaday` stays light.
    if name == "Widget":
        from .widget import Widget

        return Widget
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
