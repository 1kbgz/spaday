var __defProp = Object.defineProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// dist/pkg/spaday.js
var spaday_exports = {};
__export(spaday_exports, {
  apply: () => apply,
  decode_frame: () => decode_frame,
  default: () => __wbg_init,
  diff: () => diff,
  encode_frame: () => encode_frame,
  initSync: () => initSync,
  interpret: () => interpret,
  parse_cem: () => parse_cem
});
function apply(root, patch) {
  let deferred4_0;
  let deferred4_1;
  try {
    const ptr0 = passStringToWasm0(root, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ptr1 = passStringToWasm0(patch, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len1 = WASM_VECTOR_LEN;
    const ret = wasm.apply(ptr0, len0, ptr1, len1);
    var ptr3 = ret[0];
    var len3 = ret[1];
    if (ret[3]) {
      ptr3 = 0;
      len3 = 0;
      throw takeFromExternrefTable0(ret[2]);
    }
    deferred4_0 = ptr3;
    deferred4_1 = len3;
    return getStringFromWasm0(ptr3, len3);
  } finally {
    wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
  }
}
function decode_frame(frame) {
  let deferred3_0;
  let deferred3_1;
  try {
    const ptr0 = passArray8ToWasm0(frame, wasm.__wbindgen_malloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.decode_frame(ptr0, len0);
    var ptr2 = ret[0];
    var len2 = ret[1];
    if (ret[3]) {
      ptr2 = 0;
      len2 = 0;
      throw takeFromExternrefTable0(ret[2]);
    }
    deferred3_0 = ptr2;
    deferred3_1 = len2;
    return getStringFromWasm0(ptr2, len2);
  } finally {
    wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
  }
}
function diff(old, _new) {
  let deferred4_0;
  let deferred4_1;
  try {
    const ptr0 = passStringToWasm0(old, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ptr1 = passStringToWasm0(_new, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len1 = WASM_VECTOR_LEN;
    const ret = wasm.diff(ptr0, len0, ptr1, len1);
    var ptr3 = ret[0];
    var len3 = ret[1];
    if (ret[3]) {
      ptr3 = 0;
      len3 = 0;
      throw takeFromExternrefTable0(ret[2]);
    }
    deferred4_0 = ptr3;
    deferred4_1 = len3;
    return getStringFromWasm0(ptr3, len3);
  } finally {
    wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
  }
}
function encode_frame(payload, model_type, kind, rev, codec) {
  const ptr0 = passStringToWasm0(payload, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
  const len0 = WASM_VECTOR_LEN;
  const ptr1 = passStringToWasm0(model_type, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
  const len1 = WASM_VECTOR_LEN;
  const ptr2 = passStringToWasm0(kind, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
  const len2 = WASM_VECTOR_LEN;
  const ptr3 = passStringToWasm0(codec, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
  const len3 = WASM_VECTOR_LEN;
  const ret = wasm.encode_frame(ptr0, len0, ptr1, len1, ptr2, len2, rev, ptr3, len3);
  if (ret[3]) {
    throw takeFromExternrefTable0(ret[2]);
  }
  var v5 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
  wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
  return v5;
}
function interpret(action, host2) {
  const ptr0 = passStringToWasm0(action, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
  const len0 = WASM_VECTOR_LEN;
  const ret = wasm.interpret(ptr0, len0, host2);
  if (ret[1]) {
    throw takeFromExternrefTable0(ret[0]);
  }
}
function parse_cem(manifest) {
  let deferred3_0;
  let deferred3_1;
  try {
    const ptr0 = passStringToWasm0(manifest, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.parse_cem(ptr0, len0);
    var ptr2 = ret[0];
    var len2 = ret[1];
    if (ret[3]) {
      ptr2 = 0;
      len2 = 0;
      throw takeFromExternrefTable0(ret[2]);
    }
    deferred3_0 = ptr2;
    deferred3_1 = len2;
    return getStringFromWasm0(ptr2, len2);
  } finally {
    wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
  }
}
function __wbg_get_imports() {
  const import0 = {
    __proto__: null,
    __wbg_Error_92b29b0548f8b746: function(arg0, arg1) {
      const ret = Error(getStringFromWasm0(arg0, arg1));
      return ret;
    },
    __wbg___wbindgen_boolean_get_fa956cfa2d1bd751: function(arg0) {
      const v = arg0;
      const ret = typeof v === "boolean" ? v : void 0;
      return isLikeNone(ret) ? 16777215 : ret ? 1 : 0;
    },
    __wbg___wbindgen_is_null_ea9085d691f535d3: function(arg0) {
      const ret = arg0 === null;
      return ret;
    },
    __wbg___wbindgen_is_string_ea5e6cc2e4141dfe: function(arg0) {
      const ret = typeof arg0 === "string";
      return ret;
    },
    __wbg___wbindgen_is_undefined_c05833b95a3cf397: function(arg0) {
      const ret = arg0 === void 0;
      return ret;
    },
    __wbg___wbindgen_number_get_394265ed1e1b84ee: function(arg0, arg1) {
      const obj = arg1;
      const ret = typeof obj === "number" ? obj : void 0;
      getDataViewMemory0().setFloat64(arg0 + 8 * 1, isLikeNone(ret) ? 0 : ret, true);
      getDataViewMemory0().setInt32(arg0 + 4 * 0, !isLikeNone(ret), true);
    },
    __wbg___wbindgen_string_get_b0ca35b86a603356: function(arg0, arg1) {
      const obj = arg1;
      const ret = typeof obj === "string" ? obj : void 0;
      var ptr1 = isLikeNone(ret) ? 0 : passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
      var len1 = WASM_VECTOR_LEN;
      getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
      getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
    },
    __wbg___wbindgen_throw_344f42d3211c4765: function(arg0, arg1) {
      throw new Error(getStringFromWasm0(arg0, arg1));
    },
    __wbg_callEndpoint_dc10f1bab7383dda: function(arg0, arg1, arg2, arg3, arg4, arg5, arg6) {
      arg0.callEndpoint(getStringFromWasm0(arg1, arg2), arg3, arg4, arg5 === 0 ? void 0 : getStringFromWasm0(arg5, arg6));
    },
    __wbg_callNamed_72dec18d6a06bc1d: function(arg0, arg1, arg2) {
      arg0.callNamed(getStringFromWasm0(arg1, arg2));
    },
    __wbg_currentTarget_781c311de96e30c6: function(arg0) {
      const ret = arg0.currentTarget();
      return ret;
    },
    __wbg_emit_737d2be4fecb5218: function(arg0, arg1, arg2, arg3) {
      arg0.emit(getStringFromWasm0(arg1, arg2), arg3);
    },
    __wbg_eventValue_6caa713c47756d82: function(arg0) {
      const ret = arg0.eventValue();
      return ret;
    },
    __wbg_getField_0e0c8f01fb8a9133: function(arg0, arg1, arg2) {
      const ret = arg0.getField(getStringFromWasm0(arg1, arg2));
      return ret;
    },
    __wbg_getItem_e2c7e1ed0b19a3df: function(arg0, arg1, arg2) {
      const ret = arg0.getItem(getStringFromWasm0(arg1, arg2));
      return ret;
    },
    __wbg_getProp_a1c3748f91790646: function(arg0, arg1, arg2, arg3) {
      const ret = arg0.getProp(arg1, getStringFromWasm0(arg2, arg3));
      return ret;
    },
    __wbg_getScope_a58e3650cc96c622: function(arg0, arg1, arg2, arg3, arg4) {
      const ret = arg0.getScope(getStringFromWasm0(arg1, arg2), getStringFromWasm0(arg3, arg4));
      return ret;
    },
    __wbg_is_7b9d0b289033c7de: function(arg0, arg1) {
      const ret = Object.is(arg0, arg1);
      return ret;
    },
    __wbg_join_f397bbb193e8ab3d: function(arg0, arg1, arg2) {
      const ret = arg0.join(getStringFromWasm0(arg1, arg2));
      return ret;
    },
    __wbg_new_32b398fb48b6d94a: function() {
      const ret = new Array();
      return ret;
    },
    __wbg_new_7796ffc7ed656783: function() {
      const ret = /* @__PURE__ */ new Map();
      return ret;
    },
    __wbg_new_da52cf8fe3429cb2: function() {
      const ret = new Object();
      return ret;
    },
    __wbg_push_d2ae3af0c1217ae6: function(arg0, arg1) {
      const ret = arg0.push(arg1);
      return ret;
    },
    __wbg_queryId_4736d15abc5a0033: function(arg0, arg1, arg2) {
      const ret = arg0.queryId(getStringFromWasm0(arg1, arg2));
      return ret;
    },
    __wbg_sendPatch_b0c527efcf023115: function(arg0, arg1, arg2, arg3, arg4, arg5) {
      arg0.sendPatch(getStringFromWasm0(arg1, arg2), getStringFromWasm0(arg3, arg4), arg5);
    },
    __wbg_setField_3b0b8bb6a27ce3a8: function(arg0, arg1, arg2, arg3) {
      arg0.setField(getStringFromWasm0(arg1, arg2), arg3);
    },
    __wbg_setProp_7b85f56bfeeb991c: function(arg0, arg1, arg2, arg3, arg4) {
      arg0.setProp(arg1, getStringFromWasm0(arg2, arg3), arg4);
    },
    __wbg_set_575dd786d51585f8: function(arg0, arg1, arg2) {
      const ret = arg0.set(arg1, arg2);
      return ret;
    },
    __wbg_set_6be42768c690e380: function(arg0, arg1, arg2) {
      arg0[arg1] = arg2;
    },
    __wbg_set_8535240470bf2500: function() {
      return handleError(function(arg0, arg1, arg2) {
        const ret = Reflect.set(arg0, arg1, arg2);
        return ret;
      }, arguments);
    },
    __wbg_set_8a16b38e4805b298: function(arg0, arg1, arg2) {
      arg0[arg1 >>> 0] = arg2;
    },
    __wbindgen_cast_0000000000000001: function(arg0) {
      const ret = arg0;
      return ret;
    },
    __wbindgen_cast_0000000000000002: function(arg0) {
      const ret = arg0;
      return ret;
    },
    __wbindgen_cast_0000000000000003: function(arg0, arg1) {
      const ret = getStringFromWasm0(arg0, arg1);
      return ret;
    },
    __wbindgen_cast_0000000000000004: function(arg0) {
      const ret = BigInt.asUintN(64, arg0);
      return ret;
    },
    __wbindgen_init_externref_table: function() {
      const table = wasm.__wbindgen_externrefs;
      const offset = table.grow(4);
      table.set(0, void 0);
      table.set(offset + 0, void 0);
      table.set(offset + 1, null);
      table.set(offset + 2, true);
      table.set(offset + 3, false);
    }
  };
  return {
    __proto__: null,
    "./spaday_bg.js": import0
  };
}
function addToExternrefTable0(obj) {
  const idx = wasm.__externref_table_alloc();
  wasm.__wbindgen_externrefs.set(idx, obj);
  return idx;
}
function getArrayU8FromWasm0(ptr, len) {
  ptr = ptr >>> 0;
  return getUint8ArrayMemory0().subarray(ptr / 1, ptr / 1 + len);
}
var cachedDataViewMemory0 = null;
function getDataViewMemory0() {
  if (cachedDataViewMemory0 === null || cachedDataViewMemory0.buffer.detached === true || cachedDataViewMemory0.buffer.detached === void 0 && cachedDataViewMemory0.buffer !== wasm.memory.buffer) {
    cachedDataViewMemory0 = new DataView(wasm.memory.buffer);
  }
  return cachedDataViewMemory0;
}
function getStringFromWasm0(ptr, len) {
  return decodeText(ptr >>> 0, len);
}
var cachedUint8ArrayMemory0 = null;
function getUint8ArrayMemory0() {
  if (cachedUint8ArrayMemory0 === null || cachedUint8ArrayMemory0.byteLength === 0) {
    cachedUint8ArrayMemory0 = new Uint8Array(wasm.memory.buffer);
  }
  return cachedUint8ArrayMemory0;
}
function handleError(f, args) {
  try {
    return f.apply(this, args);
  } catch (e) {
    const idx = addToExternrefTable0(e);
    wasm.__wbindgen_exn_store(idx);
  }
}
function isLikeNone(x) {
  return x === void 0 || x === null;
}
function passArray8ToWasm0(arg, malloc) {
  const ptr = malloc(arg.length * 1, 1) >>> 0;
  getUint8ArrayMemory0().set(arg, ptr / 1);
  WASM_VECTOR_LEN = arg.length;
  return ptr;
}
function passStringToWasm0(arg, malloc, realloc) {
  if (realloc === void 0) {
    const buf = cachedTextEncoder.encode(arg);
    const ptr2 = malloc(buf.length, 1) >>> 0;
    getUint8ArrayMemory0().subarray(ptr2, ptr2 + buf.length).set(buf);
    WASM_VECTOR_LEN = buf.length;
    return ptr2;
  }
  let len = arg.length;
  let ptr = malloc(len, 1) >>> 0;
  const mem = getUint8ArrayMemory0();
  let offset = 0;
  for (; offset < len; offset++) {
    const code = arg.charCodeAt(offset);
    if (code > 127) break;
    mem[ptr + offset] = code;
  }
  if (offset !== len) {
    if (offset !== 0) {
      arg = arg.slice(offset);
    }
    ptr = realloc(ptr, len, len = offset + arg.length * 3, 1) >>> 0;
    const view = getUint8ArrayMemory0().subarray(ptr + offset, ptr + len);
    const ret = cachedTextEncoder.encodeInto(arg, view);
    offset += ret.written;
    ptr = realloc(ptr, len, offset, 1) >>> 0;
  }
  WASM_VECTOR_LEN = offset;
  return ptr;
}
function takeFromExternrefTable0(idx) {
  const value = wasm.__wbindgen_externrefs.get(idx);
  wasm.__externref_table_dealloc(idx);
  return value;
}
var cachedTextDecoder = new TextDecoder("utf-8", { ignoreBOM: true, fatal: true });
cachedTextDecoder.decode();
var MAX_SAFARI_DECODE_BYTES = 2146435072;
var numBytesDecoded = 0;
function decodeText(ptr, len) {
  numBytesDecoded += len;
  if (numBytesDecoded >= MAX_SAFARI_DECODE_BYTES) {
    cachedTextDecoder = new TextDecoder("utf-8", { ignoreBOM: true, fatal: true });
    cachedTextDecoder.decode();
    numBytesDecoded = len;
  }
  return cachedTextDecoder.decode(getUint8ArrayMemory0().subarray(ptr, ptr + len));
}
var cachedTextEncoder = new TextEncoder();
if (!("encodeInto" in cachedTextEncoder)) {
  cachedTextEncoder.encodeInto = function(arg, view) {
    const buf = cachedTextEncoder.encode(arg);
    view.set(buf);
    return {
      read: arg.length,
      written: buf.length
    };
  };
}
var WASM_VECTOR_LEN = 0;
var wasmModule;
var wasmInstance;
var wasm;
function __wbg_finalize_init(instance, module) {
  wasmInstance = instance;
  wasm = instance.exports;
  wasmModule = module;
  cachedDataViewMemory0 = null;
  cachedUint8ArrayMemory0 = null;
  wasm.__wbindgen_start();
  return wasm;
}
async function __wbg_load(module, imports) {
  if (typeof Response === "function" && module instanceof Response) {
    if (typeof WebAssembly.instantiateStreaming === "function") {
      try {
        return await WebAssembly.instantiateStreaming(module, imports);
      } catch (e) {
        const validResponse = module.ok && expectedResponseType(module.type);
        if (validResponse && module.headers.get("Content-Type") !== "application/wasm") {
          console.warn("`WebAssembly.instantiateStreaming` failed because your server does not serve Wasm with `application/wasm` MIME type. Falling back to `WebAssembly.instantiate` which is slower. Original error:\n", e);
        } else {
          throw e;
        }
      }
    }
    const bytes = await module.arrayBuffer();
    return await WebAssembly.instantiate(bytes, imports);
  } else {
    const instance = await WebAssembly.instantiate(module, imports);
    if (instance instanceof WebAssembly.Instance) {
      return { instance, module };
    } else {
      return instance;
    }
  }
  function expectedResponseType(type) {
    switch (type) {
      case "basic":
      case "cors":
      case "default":
        return true;
    }
    return false;
  }
}
function initSync(module) {
  if (wasm !== void 0) return wasm;
  if (module !== void 0) {
    if (Object.getPrototypeOf(module) === Object.prototype) {
      ({ module } = module);
    } else {
      console.warn("using deprecated parameters for `initSync()`; pass a single object instead");
    }
  }
  const imports = __wbg_get_imports();
  if (!(module instanceof WebAssembly.Module)) {
    module = new WebAssembly.Module(module);
  }
  const instance = new WebAssembly.Instance(module, imports);
  return __wbg_finalize_init(instance, module);
}
async function __wbg_init(module_or_path) {
  if (wasm !== void 0) return wasm;
  if (module_or_path !== void 0) {
    if (Object.getPrototypeOf(module_or_path) === Object.prototype) {
      ({ module_or_path } = module_or_path);
    } else {
      console.warn("using deprecated parameters for the initialization function; pass a single object instead");
    }
  }
  if (module_or_path === void 0) {
    module_or_path = new URL("spaday_bg.wasm", import.meta.url);
  }
  const imports = __wbg_get_imports();
  if (typeof module_or_path === "string" || typeof Request === "function" && module_or_path instanceof Request || typeof URL === "function" && module_or_path instanceof URL) {
    module_or_path = fetch(module_or_path);
  }
  const { instance, module } = await __wbg_load(await module_or_path, imports);
  return __wbg_finalize_init(instance, module);
}

// src/ts/wasm-ready.ts
var ready = false;
function markReady() {
  ready = true;
}
function assertReady() {
  if (!ready) {
    throw new Error(
      'spaday: the wasm core is not initialized \u2014 `await init({ module_or_path: "\u2026/spaday_bg.wasm" })` before interacting with components that carry actions.'
    );
  }
}

// src/ts/cem.ts
var parseCem = (manifest) => JSON.parse(parse_cem(manifest));
var registry = (manifest) => new Map(parseCem(manifest).map((s) => [s.tag_name, s]));

// src/ts/handlers.ts
var handlers = /* @__PURE__ */ new Map();
function registerHandler(name, fn) {
  handlers.set(name, fn);
}
function getHandler(name) {
  return handlers.get(name);
}

// src/ts/actions.ts
function interpret2(action, ctx) {
  assertReady();
  interpret(JSON.stringify(action), host(ctx));
}
function readProp(el, name) {
  if (name in el) return el[name];
  return el.hasAttribute(name) ? el.getAttribute(name) : null;
}
function host(ctx) {
  return {
    currentTarget: () => ctx.currentTarget,
    queryId: (id) => ctx.currentTarget.getRootNode().querySelector(
      "#" + CSS.escape(id)
    ),
    getProp: (el, name) => readProp(el, name),
    setProp: (el, name, value) => setProp(el, name, value),
    eventValue: () => {
      const target = ctx.event.target;
      if (target && typeof target.checked === "boolean") return target.checked;
      if (target && "value" in target) return target.value;
      return ctx.event.detail;
    },
    // a reactive state field from the mounted signal store (undefined if the tree has no store)
    getField: (name) => ctx.store?.get(name),
    getItem: (path) => ctx.scope?.get(path),
    getScope: (name, path) => ctx.scope?.resolve(name)?.get(path),
    // write a reactive state field (SetField/ToggleField) — a no-op if the tree has no store
    setField: (name, value) => ctx.store?.set(name, value),
    emit: (event, detail) => ctx.currentTarget.dispatchEvent(
      new CustomEvent(event, { detail, bubbles: true })
    ),
    // SendPatch is surfaced as a bubbling intent the app routes to its wire (e.g. a transports edit).
    sendPatch: (model, field, value) => ctx.currentTarget.dispatchEvent(
      new CustomEvent("spaday:patch", {
        detail: { model, field, value },
        bubbles: true
      })
    ),
    // CallEndpoint: the one intentional server round-trip. With a result field, the response is
    // written to the store as {status, ok, body} on completion (so the outcome can drive reactive
    // UI, e.g. show a 422 validation error); without one it stays fire-and-forget.
    callEndpoint: (method, url, body, result) => {
      const request = fetch(String(url), {
        method,
        headers: body === void 0 ? void 0 : { "content-type": "application/json" },
        body: body === void 0 ? void 0 : JSON.stringify(body)
      });
      if (!result || !ctx.store) return void request;
      const store = ctx.store;
      void request.then(async (r) => {
        const text = await r.text();
        let parsed;
        try {
          parsed = JSON.parse(text);
        } catch {
          parsed = text;
        }
        return { status: r.status, ok: r.ok, body: parsed };
      }).catch((err) => ({ status: 0, ok: false, body: String(err) })).then((outcome) => store.set(result, outcome));
    },
    // NamedJs escape hatch: invoke a pre-registered handler by name (no eval).
    callNamed: (handler) => getHandler(handler)?.(ctx.event, ctx.currentTarget)
  };
}

// src/ts/signals.ts
var isObj = (v) => v != null && typeof v === "object" && !Array.isArray(v);
function readPath(value, path) {
  if (!path) return value;
  let current = value;
  for (const part of path.split(".")) {
    if (Array.isArray(current)) {
      const index = Number(part);
      if (!Number.isSafeInteger(index) || index < 0 || index >= current.length)
        return void 0;
      current = current[index];
    } else if (isObj(current) && part in current) {
      current = current[part];
    } else {
      return void 0;
    }
  }
  return current;
}
var Scope = class {
  constructor(value, name, parent) {
    this.value = value;
    this.name = name;
    this.parent = parent;
  }
  value;
  name;
  parent;
  subscribers = /* @__PURE__ */ new Set();
  get(path = "") {
    return readPath(this.value, path);
  }
  resolve(name) {
    for (let scope = this; scope; scope = scope.parent) {
      if (scope.name === name) return scope;
    }
    return void 0;
  }
  set(value) {
    if (Object.is(this.value, value)) return;
    this.value = value;
    for (const subscriber of [...this.subscribers]) subscriber();
  }
  subscribe(subscriber) {
    this.subscribers.add(subscriber);
    return () => this.subscribers.delete(subscriber);
  }
};
function setPath(obj, parts, value) {
  const [head, ...rest] = parts;
  const clone = { ...obj };
  clone[head] = rest.length ? setPath(isObj(clone[head]) ? clone[head] : {}, rest, value) : value;
  return clone;
}
var Store = class {
  values;
  subscribers = /* @__PURE__ */ new Map();
  collectionSubscribers = /* @__PURE__ */ new Map();
  subscriberIndex = { children: /* @__PURE__ */ new Map() };
  constructor(initial = {}) {
    this.values = new Map(Object.entries(initial));
  }
  /** Read a field; a dotted `field` walks into nested objects (undefined if the path breaks). */
  get(field) {
    const [head, ...rest] = field.split(".");
    let v = this.values.get(head);
    for (const p of rest) {
      if (!isObj(v)) return void 0;
      v = v[p];
    }
    return v;
  }
  has(field) {
    const [head, ...rest] = field.split(".");
    if (!this.values.has(head)) return false;
    let v = this.values.get(head);
    for (const p of rest) {
      if (!isObj(v) || !(p in v)) return false;
      v = v[p];
    }
    return true;
  }
  index(field) {
    let node = this.subscriberIndex;
    for (const part of field.split(".")) {
      let child = node.children.get(part);
      if (!child) {
        child = { children: /* @__PURE__ */ new Map() };
        node.children.set(part, child);
      }
      node = child;
    }
    node.field = field;
  }
  unindex(field) {
    const chain = [];
    let node = this.subscriberIndex;
    for (const part of field.split(".")) {
      const child = node.children.get(part);
      if (!child) return;
      chain.push([node, part, child]);
      node = child;
    }
    delete node.field;
    for (let i = chain.length - 1; i >= 0; i -= 1) {
      const [parent, part, child] = chain[i];
      if (child.field || child.children.size) break;
      parent.children.delete(part);
    }
  }
  related(field) {
    const related = [];
    let node = this.subscriberIndex;
    for (const part of field.split(".")) {
      const child = node.children.get(part);
      if (!child) return related;
      node = child;
      if (node.field) related.push(node.field);
    }
    const descendants = [...node.children.values()];
    while (descendants.length) {
      const child = descendants.pop();
      if (child.field) related.push(child.field);
      descendants.push(...child.children.values());
    }
    return related;
  }
  hasSubscribers(field) {
    return this.subscribers.has(field) || this.collectionSubscribers.has(field);
  }
  write(field, value, deltas) {
    if (Object.is(this.get(field), value)) return;
    const related = this.related(field);
    const before = new Map(related.map((key) => [key, this.get(key)]));
    const parts = field.split(".");
    if (parts.length === 1) {
      this.values.set(field, value);
    } else {
      const head = parts[0];
      const root = isObj(this.values.get(head)) ? this.values.get(head) : {};
      this.values.set(
        head,
        setPath(root, parts.slice(1), value)
      );
    }
    for (const key of related) {
      const now = this.get(key);
      if (Object.is(before.get(key), now)) continue;
      const subscribers = this.subscribers.get(key);
      if (subscribers) for (const cb of [...subscribers]) cb(now);
      const collectionSubscribers = this.collectionSubscribers.get(key);
      if (!collectionSubscribers) continue;
      const changes = key === field && deltas ? deltas : [{ kind: "reset", items: Array.isArray(now) ? now : [] }];
      for (const delta of changes) {
        for (const subscription of [...collectionSubscribers])
          subscription.subscriber(delta);
      }
    }
  }
  /**
   * Set a field and notify subscribers; a no-op if unchanged. A dotted `field` sets a nested leaf,
   * rebuilding its parents immutably, and notifies the leaf plus its ancestors (whose identity changed)
   * and any subscribed descendant whose value changed.
   */
  set(field, value) {
    this.write(field, value);
  }
  /**
   * Store an already-updated collection and publish its granular changes to structural subscribers.
   * Ordinary field subscribers still receive the final collection once.
   */
  setCollection(field, items, deltas) {
    this.write(
      field,
      items,
      deltas.length ? deltas : [{ kind: "reset", items }]
    );
  }
  /** Subscribe to a field; returns an unsubscribe function. */
  subscribe(field, cb) {
    let subs = this.subscribers.get(field);
    if (!subs) {
      this.subscribers.set(field, subs = /* @__PURE__ */ new Set());
      this.index(field);
    }
    subs.add(cb);
    return () => {
      subs.delete(cb);
      if (!subs.size && this.subscribers.get(field) === subs) {
        this.subscribers.delete(field);
        if (!this.hasSubscribers(field)) this.unindex(field);
      }
    };
  }
  /** Return the shared item key for a field's structural subscribers, if they agree on one. */
  collectionKey(field) {
    const subscriptions = this.collectionSubscribers.get(field);
    if (!subscriptions?.size) return void 0;
    let key;
    for (const subscription of subscriptions) {
      if (key !== void 0 && key !== subscription.key) return void 0;
      key = subscription.key;
    }
    return key;
  }
  /** Subscribe to keyed structural changes; ordinary `set` calls arrive as a reset. */
  subscribeCollection(field, key, cb) {
    const subscriber = cb;
    const subscription = { key, subscriber };
    let subs = this.collectionSubscribers.get(field);
    if (!subs) {
      this.collectionSubscribers.set(field, subs = /* @__PURE__ */ new Set());
      this.index(field);
    }
    subs.add(subscription);
    return () => {
      subs.delete(subscription);
      if (!subs.size && this.collectionSubscribers.get(field) === subs) {
        this.collectionSubscribers.delete(field);
        if (!this.hasSubscribers(field)) this.unindex(field);
      }
    };
  }
};
function evalExpr(expr, store, scope) {
  if (!expr || typeof expr !== "object") return expr;
  const e = expr;
  switch (e.expr) {
    case "lit":
      return e.value;
    case "field":
      return store?.get(e.name);
    case "item":
      return scope?.get(e.path);
    case "scope":
      return scope?.resolve(e.name)?.get(e.path);
    case "not":
      return !evalExpr(e.of, store, scope);
    case "eq":
      return Object.is(
        evalExpr(e.a, store, scope),
        evalExpr(e.b, store, scope)
      );
    case "all":
      return e.of.every((x) => !!evalExpr(x, store, scope));
    case "any":
      return e.of.some((x) => !!evalExpr(x, store, scope));
    case "cond":
      return evalExpr(e.test, store, scope) ? evalExpr(e.then, store, scope) : evalExpr(e["else"], store, scope);
    case "obj": {
      const out = {};
      for (const [k, v] of Object.entries(e.fields))
        out[k] = evalExpr(v, store, scope);
      return out;
    }
    case "concat":
      return e.parts.map((part) => String(evalExpr(part, store, scope))).join("");
    default:
      return void 0;
  }
}
function exprFields(expr, out = /* @__PURE__ */ new Set()) {
  if (!expr || typeof expr !== "object") return out;
  const e = expr;
  if (e.expr === "field" && typeof e.name === "string") out.add(e.name);
  for (const [key, value] of Object.entries(e)) {
    if (key === "value") continue;
    if (Array.isArray(value)) value.forEach((v) => exprFields(v, out));
    else if (value && typeof value === "object") exprFields(value, out);
  }
  return out;
}
function exprScopes(expr, scope, out = /* @__PURE__ */ new Set()) {
  if (!expr || typeof expr !== "object") return out;
  const e = expr;
  if (e.expr === "item" && scope) out.add(scope);
  if (e.expr === "scope" && scope && typeof e.name === "string") {
    const named = scope.resolve(e.name);
    if (named) out.add(named);
  }
  for (const [key, value] of Object.entries(e)) {
    if (key === "value") continue;
    if (Array.isArray(value))
      value.forEach((nested) => exprScopes(nested, scope, out));
    else if (value && typeof value === "object") exprScopes(value, scope, out);
  }
  return out;
}

// src/ts/value.ts
function untag(value) {
  if (value === "Null") return null;
  if ("Bool" in value) return value.Bool;
  if ("Int" in value) return value.Int;
  if ("Float" in value) return value.Float;
  if ("Str" in value) return value.Str;
  if ("List" in value) return value.List.map(untag);
  if ("Map" in value)
    return Object.fromEntries(
      Object.entries(value.Map).map(([k, v]) => [k, untag(v)])
    );
  throw new Error(`unrecognized tagged value: ${JSON.stringify(value)}`);
}
function tag(value) {
  if (value === null || value === void 0) return "Null";
  if (typeof value === "boolean") return { Bool: value };
  if (typeof value === "number")
    return Number.isInteger(value) ? { Int: value } : { Float: value };
  if (typeof value === "string") return { Str: value };
  if (Array.isArray(value)) return { List: value.map(tag) };
  if (typeof value === "object")
    return {
      Map: Object.fromEntries(
        Object.entries(value).map(([k, v]) => [
          k,
          tag(v)
        ])
      )
    };
  throw new Error(`unsupported value type: ${typeof value}`);
}

// src/ts/runtime.ts
var DEFAULT_SLOT = "default";
function mount(container, tree, store, scope) {
  const el = build(tree, store, scope);
  container.appendChild(el);
  return el;
}
function applyPatch(root, patch, store, scope) {
  let current = root;
  for (const op of patch.ops) current = applyOp(current, op, store, scope);
  return current;
}
function hydrate(container, tree, store, scope) {
  const el = container.firstElementChild;
  if (!el) return mount(container, tree, store, scope);
  hydrateNode(el, tree, store, scope);
  return el;
}
function hydrateNode(el, node, store, scope) {
  for (const [name, value] of Object.entries(node.props ?? {})) {
    setProp(el, name, untag(value));
  }
  if (node.tag === "spa-show") {
    wireShow(el, node, store, scope);
  } else if (node.tag === "spa-each") {
    wireEach(el, node, store, scope);
  } else {
    for (const [slot, children] of Object.entries(node.slots ?? {})) {
      const existing = childrenInSlot(el, slot);
      children.forEach((child, i) => {
        if (existing[i]) hydrateNode(existing[i], child, store, scope);
        else appendInSlot(el, slot, build(child, store, scope));
      });
    }
  }
  for (const [name, action] of Object.entries(node.events ?? {})) {
    bindEvent(el, name, action, store, scope);
  }
  if (store || scope) {
    for (const [prop, spec] of Object.entries(node.bindings ?? {})) {
      if (isStructuralBinding(node, prop)) continue;
      wireBinding(el, prop, spec, store, scope);
    }
  }
}
var listeners = /* @__PURE__ */ new WeakMap();
function bindEvent(el, name, action, store, scope) {
  let map = listeners.get(el);
  if (!map) listeners.set(el, map = /* @__PURE__ */ new Map());
  const existing = map.get(name);
  if (existing) el.removeEventListener(name, existing);
  const handler = (event) => interpret2(action, { event, currentTarget: el, store, scope });
  el.addEventListener(name, handler);
  map.set(name, handler);
}
function unbindEvent(el, name) {
  const map = listeners.get(el);
  const handler = map?.get(name);
  if (handler) {
    el.removeEventListener(name, handler);
    map.delete(name);
  }
}
var bindings = /* @__PURE__ */ new WeakMap();
var structuralNodes = /* @__PURE__ */ new WeakMap();
var VALUE_EVENTS = ["change", "input", "wa-tab-show"];
function readProp2(el, name) {
  if (name in el) return el[name];
  return el.hasAttribute(name) ? el.getAttribute(name) : null;
}
function bindingApply(el, prop) {
  const ROOT_CLASS = "root-class:";
  if (prop.startsWith(ROOT_CLASS)) {
    const name = prop.slice(ROOT_CLASS.length);
    return (v) => document.documentElement.classList.toggle(name, !!v);
  }
  return (v) => setProp(el, prop, v);
}
function wireBinding(el, prop, spec, store, scope) {
  unwireBinding(el, prop);
  const teardowns = [];
  const apply3 = bindingApply(el, prop);
  if (spec.compute !== void 0) {
    const recompute = () => apply3(evalExpr(spec.compute, store, scope));
    recompute();
    if (store)
      for (const field of exprFields(spec.compute)) {
        teardowns.push(store.subscribe(field, recompute));
      }
    for (const dependency of exprScopes(spec.compute, scope))
      teardowns.push(dependency.subscribe(recompute));
  } else if (spec.field !== void 0 && store) {
    if (store.has(spec.field)) apply3(store.get(spec.field));
    teardowns.push(store.subscribe(spec.field, (v) => apply3(v)));
    if (spec.mode === "two-way") {
      const onChange = () => {
        const v = el;
        if (typeof v.checkValidity === "function" && !v.checkValidity()) return;
        store.set(spec.field, readProp2(el, prop));
      };
      for (const ev of VALUE_EVENTS) el.addEventListener(ev, onChange);
      teardowns.push(() => {
        for (const ev of VALUE_EVENTS) el.removeEventListener(ev, onChange);
      });
    }
  }
  let map = bindings.get(el);
  if (!map) bindings.set(el, map = /* @__PURE__ */ new Map());
  map.set(prop, () => teardowns.forEach((t) => t()));
}
function unwireBinding(el, prop) {
  const map = bindings.get(el);
  const teardown = map?.get(prop);
  if (teardown) {
    teardown();
    map.delete(prop);
  }
}
function wireShow(el, node, store, scope) {
  structuralNodes.set(el, node);
  const cond = node.bindings?.when;
  const childDefs = node.slots?.[DEFAULT_SLOT] ?? [];
  let mounted = [];
  const clear = () => {
    for (const child of mounted) {
      teardownTree(child);
      child.remove();
    }
    mounted = [];
  };
  const inert = !cond || (cond.compute === void 0 ? !store : !store && !scope);
  if (inert) {
    for (const child of childDefs) {
      const built = build(child, store, scope);
      appendInSlot(el, DEFAULT_SLOT, built);
      mounted.push(built);
    }
    let map2 = bindings.get(el);
    if (!map2) bindings.set(el, map2 = /* @__PURE__ */ new Map());
    map2.set("when", clear);
    return;
  }
  const evaluate = () => cond.compute !== void 0 ? !!evalExpr(cond.compute, store, scope) : !!store.get(cond.field);
  const render = () => {
    if (evaluate()) {
      if (mounted.length === 0) {
        for (const c of childDefs) {
          const ce = build(c, store, scope);
          appendInSlot(el, DEFAULT_SLOT, ce);
          mounted.push(ce);
        }
      }
    } else if (mounted.length) clear();
  };
  render();
  const deps = cond.compute !== void 0 ? [...exprFields(cond.compute)] : [cond.field];
  const subs = store ? deps.map((f) => store.subscribe(f, render)) : [];
  if (cond.compute !== void 0)
    for (const dependency of exprScopes(cond.compute, scope))
      subs.push(dependency.subscribe(render));
  let map = bindings.get(el);
  if (!map) bindings.set(el, map = /* @__PURE__ */ new Map());
  map.set("when", () => {
    for (const unsubscribe of subs) unsubscribe();
    clear();
  });
}
function eachKeyIdentity(value, key) {
  if (typeof value === "string") return `string:${value}`;
  if (typeof value === "number" && Number.isFinite(value))
    return `number:${value}`;
  throw new Error(
    `spa-each key ${JSON.stringify(key)} must exist and contain a string or finite number`
  );
}
function eachIdentity(item, key) {
  return eachKeyIdentity(new Scope(item).get(key), key);
}
function keyedItems(items, key) {
  const seen = /* @__PURE__ */ new Set();
  return items.map((item) => {
    const identity = eachIdentity(item, key);
    if (seen.has(identity))
      throw new Error(
        `spa-each key ${JSON.stringify(key)} contains duplicate value ${JSON.stringify(new Scope(item).get(key))}`
      );
    seen.add(identity);
    return [identity, item];
  });
}
function collectionIndex(index, length, insert = false) {
  const maximum = insert ? length : length - 1;
  if (!Number.isSafeInteger(index) || index < 0 || index > maximum)
    throw new Error(
      `spa-each collection index ${index} is outside 0..${maximum}`
    );
}
function updateCollectionPath(current, path, value) {
  if (!path.length) return value;
  const [head, ...rest] = path;
  if (typeof head === "number") {
    if (!Array.isArray(current) || !Number.isSafeInteger(head) || head < 0 || head >= current.length)
      throw new Error(
        `spa-each collection update has invalid path segment ${head}`
      );
    const next2 = [...current];
    next2[head] = updateCollectionPath(next2[head], rest, value);
    return next2;
  }
  if (current == null || typeof current !== "object" || Array.isArray(current))
    throw new Error(
      `spa-each collection update has invalid path segment ${JSON.stringify(head)}`
    );
  const next = { ...current };
  next[head] = rest.length ? updateCollectionPath(next[head], rest, value) : value;
  return next;
}
function prepareEachDeltas(deltas, itemKey, order, instances) {
  let nextOrder;
  let values = /* @__PURE__ */ new Map();
  const currentOrder = () => nextOrder ??= [...order];
  const currentValue = (identity) => values.has(identity) ? values.get(identity) : instances.get(identity)?.scope.get();
  const prepared = [];
  for (const delta of deltas) {
    if (delta.kind === "reset") {
      const items = keyedItems(delta.items, itemKey);
      nextOrder = items.map(([identity2]) => identity2);
      values = new Map(items);
      prepared.push({ kind: "reset", items });
      continue;
    }
    if (delta.kind === "reorder") {
      const sequence = currentOrder();
      const reordered = delta.keys.map((key) => eachKeyIdentity(key, itemKey));
      const identities = new Set(reordered);
      if (reordered.length !== sequence.length || identities.size !== reordered.length || sequence.some((identity2) => !identities.has(identity2)))
        throw new Error(
          "spa-each collection reorder must contain every current key exactly once"
        );
      nextOrder = reordered;
      prepared.push({ kind: "reorder", order: [...reordered] });
      continue;
    }
    const identity = eachKeyIdentity(delta.key, itemKey);
    const exists = nextOrder ? nextOrder.includes(identity) : instances.has(identity);
    if (delta.kind === "insert") {
      const sequence = currentOrder();
      collectionIndex(delta.index, sequence.length, true);
      if (exists)
        throw new Error(
          `spa-each collection insert contains duplicate key ${JSON.stringify(delta.key)}`
        );
      if (eachIdentity(delta.item, itemKey) !== identity)
        throw new Error(
          `spa-each collection insert key ${JSON.stringify(delta.key)} does not match its item`
        );
      sequence.splice(delta.index, 0, identity);
      values.set(identity, delta.item);
      prepared.push({
        kind: "insert",
        identity,
        index: delta.index,
        item: delta.item
      });
      continue;
    }
    if (!exists)
      throw new Error(
        `spa-each collection ${delta.kind} references unknown key ${JSON.stringify(delta.key)}`
      );
    if (delta.kind === "update") {
      const item = updateCollectionPath(
        currentValue(identity),
        delta.path,
        delta.value
      );
      if (eachIdentity(item, itemKey) !== identity)
        throw new Error("spa-each collection update cannot change an item key");
      values.set(identity, item);
      prepared.push({ kind: "update", identity, item });
    } else if (delta.kind === "move") {
      const sequence = currentOrder();
      collectionIndex(delta.index, sequence.length);
      const index = sequence.indexOf(identity);
      sequence.splice(index, 1);
      sequence.splice(delta.index, 0, identity);
      prepared.push({ kind: "move", identity, index: delta.index });
    } else {
      const sequence = currentOrder();
      const index = sequence.indexOf(identity);
      sequence.splice(index, 1);
      values.delete(identity);
      prepared.push({ kind: "remove", identity });
    }
  }
  return prepared;
}
function preserveEachFocus(el, mutate) {
  const focused = document.activeElement instanceof HTMLElement && el.contains(document.activeElement) ? document.activeElement : void 0;
  let selection;
  if ((focused instanceof HTMLInputElement || focused instanceof HTMLTextAreaElement) && focused.selectionStart !== null && focused.selectionEnd !== null)
    selection = [
      focused.selectionStart,
      focused.selectionEnd,
      focused.selectionDirection
    ];
  mutate();
  if (focused) {
    focused.focus({ preventScroll: true });
    if (selection && (focused instanceof HTMLInputElement || focused instanceof HTMLTextAreaElement))
      focused.setSelectionRange(
        selection[0],
        selection[1],
        selection[2] ?? void 0
      );
  }
}
function wireEach(el, node, store, parentScope) {
  structuralNodes.set(el, node);
  const source = node.bindings?.items;
  const template = node.slots?.[DEFAULT_SLOT] ?? [];
  const itemKey = String(untag(node.props?.itemKey));
  const scopeValue = node.props?.scopeName ? untag(node.props.scopeName) : void 0;
  const scopeName = scopeValue == null ? void 0 : String(scopeValue);
  if (template.length !== 1)
    throw new Error("spa-each requires exactly one component template");
  let instances = /* @__PURE__ */ new Map();
  let order = [];
  let frame;
  let pendingDeltas;
  const evaluate = () => {
    const value = source?.compute ? evalExpr(source.compute, store, parentScope) : source?.field && store ? store.get(source.field) : [];
    return Array.isArray(value) ? value : [];
  };
  const reconcileItems = (items) => {
    const stale = new Map(instances);
    const next = /* @__PURE__ */ new Map();
    for (const [index, [identity, item]] of items.entries()) {
      let instance = instances.get(identity);
      if (instance) {
        instance.scope.set(item);
      } else {
        const itemScope = new Scope(item, scopeName, parentScope);
        instance = {
          element: build(template[0], store, itemScope),
          scope: itemScope
        };
      }
      const current = el.children[index];
      if (current !== instance.element) {
        const movable = el;
        if (instance.element.parentElement === el && typeof movable.moveBefore === "function")
          movable.moveBefore(instance.element, current ?? null);
        else el.insertBefore(instance.element, current ?? null);
      }
      stale.delete(identity);
      next.set(identity, instance);
    }
    for (const instance of stale.values()) {
      teardownTree(instance.element);
      instance.element.remove();
    }
    instances = next;
    order = items.map(([identity]) => identity);
  };
  const placeAt = (instance, index, previousIndex) => {
    if (previousIndex === index) return;
    const current = el.children[previousIndex !== void 0 && previousIndex < index ? index + 1 : index] ?? null;
    const movable = el;
    if (instance.element.parentElement === el && typeof movable.moveBefore === "function")
      movable.moveBefore(instance.element, current);
    else el.insertBefore(instance.element, current);
  };
  const applyDeltas = (deltas) => {
    const prepared = prepareEachDeltas(deltas, itemKey, order, instances);
    preserveEachFocus(el, () => {
      for (const delta of prepared) {
        if (delta.kind === "reset") {
          reconcileItems(delta.items);
        } else if (delta.kind === "insert") {
          const itemScope = new Scope(delta.item, scopeName, parentScope);
          const instance = {
            element: build(template[0], store, itemScope),
            scope: itemScope
          };
          instances.set(delta.identity, instance);
          order.splice(delta.index, 0, delta.identity);
          placeAt(instance, delta.index);
        } else if (delta.kind === "update") {
          instances.get(delta.identity).scope.set(delta.item);
        } else if (delta.kind === "move") {
          const index = order.indexOf(delta.identity);
          order.splice(index, 1);
          order.splice(delta.index, 0, delta.identity);
          placeAt(instances.get(delta.identity), delta.index, index);
        } else if (delta.kind === "reorder") {
          for (const [index, identity] of delta.order.entries())
            placeAt(instances.get(identity), index);
          order = [...delta.order];
        } else {
          const instance = instances.get(delta.identity);
          teardownTree(instance.element);
          instance.element.remove();
          instances.delete(delta.identity);
          order.splice(order.indexOf(delta.identity), 1);
        }
      }
    });
  };
  const flush = () => {
    frame = void 0;
    const deltas = pendingDeltas;
    pendingDeltas = void 0;
    if (deltas) applyDeltas(deltas);
    else
      preserveEachFocus(
        el,
        () => reconcileItems(keyedItems(evaluate(), itemKey))
      );
  };
  const schedule = () => {
    if (frame === void 0) frame = requestAnimationFrame(flush);
  };
  const scheduleReconcile = () => {
    pendingDeltas = void 0;
    schedule();
  };
  const scheduleDelta = (delta) => {
    if (delta.kind === "reset") pendingDeltas = [delta];
    else (pendingDeltas ??= []).push(delta);
    schedule();
  };
  reconcileItems(keyedItems(evaluate(), itemKey));
  const subs = [];
  if (source?.compute !== void 0) {
    if (store)
      for (const field of exprFields(source.compute))
        subs.push(store.subscribe(field, scheduleReconcile));
    for (const dependency of exprScopes(source.compute, parentScope))
      subs.push(dependency.subscribe(scheduleReconcile));
  } else if (source?.field && store) {
    subs.push(store.subscribeCollection(source.field, itemKey, scheduleDelta));
  }
  let map = bindings.get(el);
  if (!map) bindings.set(el, map = /* @__PURE__ */ new Map());
  map.set("items", () => {
    if (frame !== void 0) cancelAnimationFrame(frame);
    for (const unsubscribe of subs) unsubscribe();
    for (const instance of instances.values()) {
      teardownTree(instance.element);
      instance.element.remove();
    }
    instances.clear();
  });
}
function isStructuralBinding(node, prop) {
  return node.tag === "spa-show" && prop === "when" || node.tag === "spa-each" && prop === "items";
}
function rewireStructuralBinding(el, name, binding, store, scope) {
  const node = structuralNodes.get(el);
  if (!node || !isStructuralBinding(node, name)) return false;
  const nextBindings = { ...node.bindings };
  if (binding) nextBindings[name] = binding;
  else delete nextBindings[name];
  const next = { ...node, bindings: nextBindings };
  unwireBinding(el, name);
  if (next.tag === "spa-show") wireShow(el, next, store, scope);
  else wireEach(el, next, store, scope);
  return true;
}
function teardownTree(el) {
  for (const e of [el, ...el.querySelectorAll("*")]) {
    const map = bindings.get(e);
    if (map) {
      for (const teardown of map.values()) teardown();
      bindings.delete(e);
    }
    structuralNodes.delete(e);
  }
}
function build(node, store, scope) {
  const el = document.createElement(node.tag);
  for (const [name, value] of Object.entries(node.props ?? {})) {
    setProp(el, name, untag(value));
  }
  if (node.tag === "spa-show") {
    wireShow(el, node, store, scope);
  } else if (node.tag === "spa-each") {
    wireEach(el, node, store, scope);
  } else {
    for (const [slot, children] of Object.entries(node.slots ?? {})) {
      for (const child of children)
        appendInSlot(el, slot, build(child, store, scope));
    }
  }
  for (const [name, action] of Object.entries(node.events ?? {})) {
    bindEvent(el, name, action, store, scope);
  }
  if (store || scope) {
    for (const [prop, spec] of Object.entries(node.bindings ?? {})) {
      if (isStructuralBinding(node, prop)) continue;
      wireBinding(el, prop, spec, store, scope);
    }
  }
  return el;
}
function setProp(el, name, value) {
  if (name in el) {
    el[name] = value;
    return;
  }
  if (value === false || value === null || value === void 0) {
    el.removeAttribute(name);
  } else {
    el.setAttribute(name, value === true ? "" : String(value));
  }
}
function removeProp(el, name) {
  if (name in el) {
    setProp(el, name, void 0);
  }
  el.removeAttribute(name);
}
function slotOf(child) {
  return child.getAttribute("slot") ?? DEFAULT_SLOT;
}
function childrenInSlot(el, slot) {
  return Array.from(el.children).filter((c) => slotOf(c) === slot);
}
function appendInSlot(parent, slot, child) {
  if (slot !== DEFAULT_SLOT) child.setAttribute("slot", slot);
  insertInSlot(parent, slot, childrenInSlot(parent, slot).length, child);
}
function insertInSlot(parent, slot, index, child) {
  if (slot !== DEFAULT_SLOT) child.setAttribute("slot", slot);
  const siblings = childrenInSlot(parent, slot);
  if (index < siblings.length) {
    parent.insertBefore(child, siblings[index]);
  } else if (siblings.length > 0) {
    parent.insertBefore(child, siblings[siblings.length - 1].nextSibling);
  } else {
    parent.appendChild(child);
  }
}
function resolve(root, path) {
  let el = root;
  for (const seg of path) el = childrenInSlot(el, seg.slot)[seg.index];
  return el;
}
function applyOp(root, op, store, scope) {
  if ("SetProp" in op) {
    setProp(
      resolve(root, op.SetProp.path),
      op.SetProp.name,
      untag(op.SetProp.value)
    );
  } else if ("RemoveProp" in op) {
    removeProp(resolve(root, op.RemoveProp.path), op.RemoveProp.name);
  } else if ("SetEvent" in op) {
    const { path, name, action } = op.SetEvent;
    bindEvent(resolve(root, path), name, action, store, scope);
  } else if ("RemoveEvent" in op) {
    const { path, name } = op.RemoveEvent;
    unbindEvent(resolve(root, path), name);
  } else if ("SetBinding" in op) {
    const { path, name, binding } = op.SetBinding;
    const el = resolve(root, path);
    if (!rewireStructuralBinding(el, name, binding, store, scope)) {
      if (store || scope) wireBinding(el, name, binding, store, scope);
    }
  } else if ("RemoveBinding" in op) {
    const { path, name } = op.RemoveBinding;
    const el = resolve(root, path);
    if (!rewireStructuralBinding(el, name, void 0, store, scope))
      unwireBinding(el, name);
  } else if ("InsertChild" in op) {
    const { path, slot, index, node } = op.InsertChild;
    insertInSlot(resolve(root, path), slot, index, build(node, store, scope));
  } else if ("RemoveChild" in op) {
    const { path, slot, index } = op.RemoveChild;
    const child = childrenInSlot(resolve(root, path), slot)[index];
    teardownTree(child);
    child.remove();
  } else if ("MoveChild" in op) {
    const { path, slot, from, to } = op.MoveChild;
    const parent = resolve(root, path);
    const moving = childrenInSlot(parent, slot)[from];
    moving.remove();
    insertInSlot(parent, slot, to, moving);
  } else if ("Replace" in op) {
    const target = resolve(root, op.Replace.path);
    teardownTree(target);
    const replacement = build(op.Replace.node, store, scope);
    target.replaceWith(replacement);
    if (op.Replace.path.length === 0) return replacement;
  }
  return root;
}

// src/ts/store-sync.ts
var isObj2 = (v) => v != null && typeof v === "object" && !Array.isArray(v);
function* leaves(obj, prefix = "") {
  for (const [k, v] of Object.entries(obj)) {
    const path = prefix ? `${prefix}.${k}` : k;
    if (isObj2(v)) yield* leaves(v, path);
    else yield [path, v];
  }
}
function setPath2(obj, parts, value) {
  const [head, ...rest] = parts;
  const clone = { ...obj };
  clone[head] = rest.length ? setPath2(isObj2(clone[head]) ? clone[head] : {}, rest, value) : value;
  return clone;
}
function updatePath(value, path, update) {
  if (!path.length) return update(value);
  const [segment, ...rest] = path;
  if ("Key" in segment) {
    if (!isObj2(value)) throw new Error("patch path expected an object");
    if (rest.length && !(segment.Key in value))
      throw new Error(
        `patch path key ${JSON.stringify(segment.Key)} not found`
      );
    return {
      ...value,
      [segment.Key]: updatePath(value[segment.Key], rest, update)
    };
  }
  if (!Array.isArray(value)) throw new Error("patch path expected an array");
  if (!Number.isSafeInteger(segment.Index) || segment.Index < 0 || segment.Index >= value.length)
    throw new Error(
      `patch path index ${segment.Index} out of bounds (len ${value.length})`
    );
  const next = [...value];
  next[segment.Index] = updatePath(next[segment.Index], rest, update);
  return next;
}
function applyPlainOp(current, path, op, codec) {
  if ("Set" in op)
    return updatePath(current, path, () => codec.fromValue(op.Set.value));
  if ("Remove" in op) {
    if (!path.length) return void 0;
    const segment = path[path.length - 1];
    if (!segment || !("Key" in segment))
      throw new Error("remove path must end in an object key");
    return updatePath(current, path.slice(0, -1), (container) => {
      if (!isObj2(container)) throw new Error("remove path expected an object");
      const next = { ...container };
      delete next[segment.Key];
      return next;
    });
  }
  if ("Insert" in op) {
    return updatePath(current, path, (container) => {
      if (!Array.isArray(container))
        throw new Error("insert path expected an array");
      if (!Number.isSafeInteger(op.Insert.index) || op.Insert.index < 0 || op.Insert.index > container.length)
        throw new Error(
          `insert index ${op.Insert.index} out of bounds (len ${container.length})`
        );
      const next = [...container];
      next.splice(op.Insert.index, 0, codec.fromValue(op.Insert.value));
      return next;
    });
  }
  if ("Move" in op) {
    return updatePath(current, path, (container) => {
      if (!Array.isArray(container))
        throw new Error("move path expected an array");
      if (!Number.isSafeInteger(op.Move.from) || op.Move.from < 0 || op.Move.from >= container.length)
        throw new Error(
          `move source ${op.Move.from} out of bounds (len ${container.length})`
        );
      if (!Number.isSafeInteger(op.Move.to) || op.Move.to < 0 || op.Move.to >= container.length)
        throw new Error(
          `move destination ${op.Move.to} out of bounds (len ${container.length})`
        );
      const next = [...container];
      const [item] = next.splice(op.Move.from, 1);
      next.splice(op.Move.to, 0, item);
      return next;
    });
  }
  if ("Reorder" in op) {
    return updatePath(current, path, (container) => {
      if (!Array.isArray(container))
        throw new Error("reorder path expected an array");
      if (op.Reorder.order.length !== container.length || op.Reorder.order.some(
        (index) => !Number.isSafeInteger(index) || index < 0 || index >= container.length
      ) || new Set(op.Reorder.order).size !== container.length)
        throw new Error("reorder order must be a complete array permutation");
      return op.Reorder.order.map((index) => container[index]);
    });
  }
  return updatePath(current, path, (container) => {
    if (!Array.isArray(container))
      throw new Error("remove path expected an array");
    if (!Number.isSafeInteger(op.RemoveAt.index) || op.RemoveAt.index < 0 || op.RemoveAt.index >= container.length)
      throw new Error(
        `remove index ${op.RemoveAt.index} out of bounds (len ${container.length})`
      );
    const next = [...container];
    next.splice(op.RemoveAt.index, 1);
    return next;
  });
}
function readSegments(value, path) {
  let current = value;
  for (const segment of path) {
    if ("Key" in segment) {
      if (!isObj2(current)) return void 0;
      current = current[segment.Key];
    } else {
      if (!Array.isArray(current)) return void 0;
      current = current[segment.Index];
    }
  }
  return current;
}
function readCollectionKey(item, field) {
  let current = item;
  for (const part of field.split(".")) {
    if (Array.isArray(current)) {
      const index = Number(part);
      if (!Number.isSafeInteger(index) || index < 0 || index >= current.length)
        return void 0;
      current = current[index];
    } else if (isObj2(current)) {
      current = current[part];
    } else {
      return void 0;
    }
  }
  return typeof current === "string" || typeof current === "number" && Number.isFinite(current) ? current : void 0;
}
function collectionDeltasMatch(current, next, deltas, itemKey) {
  const identity = (item) => {
    const key = readCollectionKey(item, itemKey);
    return key === void 0 ? void 0 : `${typeof key}:${key}`;
  };
  const order = current.map(identity);
  const target = next.map(identity);
  if (order.includes(void 0) || target.includes(void 0) || new Set(order).size !== order.length || new Set(target).size !== target.length)
    return false;
  for (const delta of deltas) {
    if (delta.kind === "reset") return false;
    if (delta.kind === "reorder") {
      const reordered = delta.keys.map((key2) => `${typeof key2}:${key2}`);
      const currentKeys = new Set(order);
      if (reordered.length !== order.length || new Set(reordered).size !== reordered.length || reordered.some((key2) => !currentKeys.has(key2)))
        return false;
      order.splice(0, order.length, ...reordered);
      continue;
    }
    const key = `${typeof delta.key}:${delta.key}`;
    const index = order.indexOf(key);
    if (delta.kind === "insert") {
      if (index !== -1 || !Number.isSafeInteger(delta.index) || delta.index < 0 || delta.index > order.length || identity(delta.item) !== key)
        return false;
      order.splice(delta.index, 0, key);
    } else if (delta.kind === "update") {
      if (index === -1) return false;
    } else if (delta.kind === "move") {
      if (index === -1 || !Number.isSafeInteger(delta.index) || delta.index < 0 || delta.index >= order.length)
        return false;
      order.splice(index, 1);
      order.splice(delta.index, 0, key);
    } else {
      if (index === -1) return false;
      order.splice(index, 1);
    }
  }
  return order.length === target.length && order.every((key, index) => key === target[index]);
}
function collectionPath(path) {
  return path.map(
    (segment) => "Key" in segment ? segment.Key : segment.Index
  );
}
function collectionDelta(current, next, path, op, itemKey) {
  if (!Array.isArray(current) || !Array.isArray(next)) return void 0;
  if ("Insert" in op && path.length === 0) {
    const item = next[op.Insert.index];
    const key2 = readCollectionKey(item, itemKey);
    return key2 === void 0 ? void 0 : { kind: "insert", key: key2, index: op.Insert.index, item };
  }
  if ("RemoveAt" in op && path.length === 0) {
    const key2 = readCollectionKey(current[op.RemoveAt.index], itemKey);
    return key2 === void 0 ? void 0 : { kind: "remove", key: key2 };
  }
  if ("Move" in op && path.length === 0) {
    const key2 = readCollectionKey(current[op.Move.from], itemKey);
    return key2 === void 0 || !Object.is(key2, readCollectionKey(next[op.Move.to], itemKey)) ? void 0 : { kind: "move", key: key2, index: op.Move.to };
  }
  if ("Reorder" in op && path.length === 0) {
    const keys = next.map((item) => readCollectionKey(item, itemKey));
    return keys.includes(void 0) ? void 0 : { kind: "reorder", keys };
  }
  const [row, ...itemPath] = path;
  if (!row || !("Index" in row)) return void 0;
  const oldItem = current[row.Index];
  const newItem = next[row.Index];
  const key = readCollectionKey(oldItem, itemKey);
  if (key === void 0 || !Object.is(key, readCollectionKey(newItem, itemKey)))
    return void 0;
  let changedPath = itemPath;
  if ("Remove" in op) changedPath = itemPath.slice(0, -1);
  return {
    kind: "update",
    key,
    path: collectionPath(changedPath),
    value: readSegments(newItem, changedPath)
  };
}
function connectStore(store, client, send, codec, namespace, flatten = true) {
  let id;
  let inbound = false;
  const wired = /* @__PURE__ */ new Set();
  const unsubs = [];
  const wireField = (field) => {
    const key = namespace ? `${namespace}.${field}` : field;
    if (wired.has(key)) return;
    wired.add(key);
    unsubs.push(
      store.subscribe(key, (value) => {
        if (inbound || id === void 0) return;
        const decoded = codec.fromValue(client.value(id));
        const current = isObj2(decoded) ? decoded : {};
        send(
          client.edit(
            id,
            codec.toValue(setPath2(current, field.split("."), value))
          )
        );
      })
    );
  };
  const receiveSnapshot = () => {
    if (id === void 0) return;
    const decoded = codec.fromValue(client.value(id));
    if (!isObj2(decoded)) return;
    const entries = flatten ? leaves(decoded) : Object.entries(decoded);
    for (const [field, value] of entries) {
      const key = namespace ? `${namespace}.${field}` : field;
      store.set(key, value);
      wireField(field.split(".")[0]);
    }
  };
  const receivePatch = (change) => {
    const staged = /* @__PURE__ */ new Map();
    try {
      for (const op of change.patch.ops) {
        const body = "Set" in op ? op.Set : "Remove" in op ? op.Remove : "Insert" in op ? op.Insert : "RemoveAt" in op ? op.RemoveAt : "Move" in op ? op.Move : op.Reorder;
        const [head, ...rest] = body.path;
        if (!head) {
          receiveSnapshot();
          return;
        }
        if (!("Key" in head))
          throw new Error("model patch path must start with a map key");
        const field = head.Key;
        const key = namespace ? `${namespace}.${field}` : field;
        const current = staged.has(key) ? staged.get(key).value : store.get(key);
        const value = applyPlainOp(current, rest, op, codec);
        const itemKey = store.collectionKey(key);
        let deltas = staged.has(key) ? staged.get(key).deltas : itemKey ? [] : void 0;
        if (deltas && itemKey) {
          const delta = collectionDelta(current, value, rest, op, itemKey);
          if (delta) deltas.push(delta);
          else deltas = void 0;
        }
        staged.set(key, {
          field,
          value,
          deltas
        });
      }
    } catch {
      receiveSnapshot();
      return;
    }
    for (const [key, update] of staged) {
      const itemKey = store.collectionKey(key);
      if (update.deltas && itemKey && Array.isArray(update.value) && Array.isArray(store.get(key)) && collectionDeltasMatch(
        store.get(key),
        update.value,
        update.deltas,
        itemKey
      ))
        store.setCollection(key, update.value, update.deltas);
      else store.set(key, update.value);
      wireField(update.field);
    }
  };
  const accept = (change) => {
    if (id === void 0) id = change.id;
    if (change.id !== id) return;
    inbound = true;
    try {
      if (change.t === "patch") receivePatch(change);
      else receiveSnapshot();
    } finally {
      inbound = false;
    }
  };
  const listensForChanges = client.onChange !== void 0;
  if (client.onChange) unsubs.push(client.onChange(accept));
  return {
    receive(data) {
      const change = client.recv(data);
      if (listensForChanges) return;
      if (change) {
        accept(change);
        return;
      }
      if (id === void 0) id = client.ids()[0];
      if (id === void 0) return;
      inbound = true;
      try {
        receiveSnapshot();
      } finally {
        inbound = false;
      }
    },
    dispose() {
      for (const unsub of unsubs) unsub();
    }
  };
}

// src/ts/worker.ts
function connectWorker(container, worker) {
  let root;
  let resolveReady;
  let rejectReady;
  const ready2 = new Promise((resolve2, reject) => {
    resolveReady = resolve2;
    rejectReady = reject;
  });
  const receive = (event) => {
    const message = event.data;
    if (message.type === "snapshot") {
      if (root) root.remove();
      root = mount(container, message.tree);
      resolveReady();
    } else if (message.type === "patch") {
      if (!root) throw new Error("worker sent a patch before its snapshot");
      root = applyPatch(root, message.patch);
    } else if (message.type === "error") {
      rejectReady(new Error(message.message));
    }
  };
  const fail = (event) => rejectReady(new Error(event.message));
  const forward = (event) => {
    worker.postMessage({
      type: event.type,
      detail: event.detail
    });
  };
  worker.addEventListener("message", receive);
  worker.addEventListener("error", fail);
  container.addEventListener("spaday:patch", forward);
  worker.postMessage({ type: "start" });
  return {
    ready: ready2,
    dispose() {
      worker.removeEventListener("message", receive);
      worker.removeEventListener("error", fail);
      container.removeEventListener("spaday:patch", forward);
      root?.remove();
    }
  };
}

// src/ts/shell.ts
var BORDER = "var(--spa-border, #e6e6e6)";
var SURFACE = "var(--spa-surface, #fff)";
var SURFACE_2 = "var(--spa-surface-2, #fafafa)";
var MUTED = "var(--spa-muted, #666)";
var THEME_CSS = `:where(.wa-dark) {
  --spa-surface: #15191e;
  --spa-surface-2: #1d232b;
  --spa-border: #333b45;
  --spa-muted: #9aa3ad;
}
:where(.wa-light) {
  --spa-surface: #fff;
  --spa-surface-2: #fafafa;
  --spa-border: #e6e6e6;
  --spa-muted: #666;
}`;
var SHELL = {
  // page frame: nav (top) / body (fills) / footer (bottom), stacked
  "spa-app": ":host{display:flex;flex-direction:column;min-height:100vh}",
  // top app bar
  "spa-nav": `:host{display:flex;align-items:center;gap:var(--spa-gap, 1rem);padding:.75rem 1.25rem;border-bottom:1px solid ${BORDER};background:${SURFACE}}`,
  // middle region: gutters + main, side by side
  "spa-body": ":host{display:flex;flex:1;min-height:0}",
  // a sidebar; place before or after main to get a left/right gutter
  "spa-gutter": `:host{display:flex;flex-direction:column;gap:var(--spa-gap, .5rem);flex:none;width:var(--spa-gutter-width, 220px);padding:1rem;border-right:1px solid ${BORDER};background:${SURFACE_2}}`,
  // primary content region
  "spa-main": ":host{display:block;flex:1;min-width:0;padding:1.5rem;overflow:auto}",
  // bottom bar
  "spa-footer": `:host{padding:.6rem 1.25rem;border-top:1px solid ${BORDER};background:${SURFACE};font-size:.8rem;color:${MUTED}}`,
  // generic vertical group
  "spa-stack": ":host{display:flex;flex-direction:column;gap:var(--spa-gap, .75rem);align-items:var(--spa-align, stretch)}",
  // generic horizontal group
  "spa-row": ":host{display:flex;align-items:var(--spa-align, center);justify-content:var(--spa-justify, flex-start);gap:var(--spa-gap, 1rem)}",
  // a contained strip of actions/controls
  "spa-toolbar": `:host{display:flex;align-items:var(--spa-align, center);gap:var(--spa-gap, .5rem);padding:.5rem .6rem;background:${SURFACE_2};border:1px solid ${BORDER};border-radius:8px}`
};
var SHELL_TAGS = Object.keys(SHELL);
var ATTR_VARS = {
  gap: "--spa-gap",
  align: "--spa-align",
  justify: "--spa-justify",
  width: "--spa-gutter-width"
};
if (typeof customElements !== "undefined") {
  if (!document.querySelector("style[data-spaday-shell-theme]")) {
    const theme = document.createElement("style");
    theme.setAttribute("data-spaday-shell-theme", "");
    theme.textContent = THEME_CSS;
    document.head.append(theme);
  }
  for (const [tag2, css] of Object.entries(SHELL)) {
    if (customElements.get(tag2)) continue;
    customElements.define(
      tag2,
      class extends HTMLElement {
        static get observedAttributes() {
          return Object.keys(ATTR_VARS);
        }
        constructor() {
          super();
          const root = this.attachShadow({ mode: "open" });
          const style = document.createElement("style");
          style.textContent = css;
          root.append(style, document.createElement("slot"));
        }
        attributeChangedCallback(name, _old, value) {
          const prop = ATTR_VARS[name];
          if (!prop) return;
          if (value == null) this.style.removeProperty(prop);
          else this.style.setProperty(prop, value);
        }
      }
    );
  }
}
var TABLE_CSS = `:host{display:block;overflow:auto}
table{border-collapse:collapse;width:100%;font-size:.9rem;color:inherit}
th,td{text-align:left;padding:.4rem .65rem;border-bottom:1px solid ${BORDER};white-space:nowrap}
thead th{background:${SURFACE_2};font-weight:600;position:sticky;top:0}
tbody tr:hover td{background:${SURFACE_2}}`;
var CELL_SLOT = "__spaday_cell_slot__";
function tableCell(td, value) {
  if (typeof value === "object" && value !== null && !Array.isArray(value) && Object.keys(value).length === 1 && typeof value[CELL_SLOT] === "string") {
    const name = String(value[CELL_SLOT]);
    const existing = td.firstElementChild;
    if (td.childNodes.length === 1 && existing instanceof HTMLSlotElement && existing.name === name)
      return;
    const slot = document.createElement("slot");
    slot.name = name;
    td.replaceChildren(slot);
    return;
  }
  const text = value == null ? "" : String(value);
  if (td.childElementCount === 0 && td.textContent === text) return;
  td.textContent = text;
}
function tableColumns(cols, rows) {
  const raw = Array.isArray(cols) && cols.length ? cols : rows[0] ? Object.keys(rows[0]) : [];
  return raw.map(
    (c) => typeof c === "string" ? { key: c, label: c } : {
      key: String(c.key),
      label: String(
        c.label ?? c.key
      )
    }
  );
}
function sameColumns(a, b) {
  return a.length === b.length && a.every(
    (column, i) => column.key === b[i].key && column.label === b[i].label
  );
}
function rowIdentity(row, rowKey) {
  const value = row[rowKey];
  if (typeof value === "string") return `string:${value}`;
  if (typeof value === "number" && Number.isFinite(value))
    return `number:${value}`;
  throw new Error(
    `spa-table row_key ${JSON.stringify(rowKey)} must exist and contain a string or finite number`
  );
}
function keyedRows(rows, rowKey) {
  const seen = /* @__PURE__ */ new Set();
  return rows.map((row) => {
    const identity = rowIdentity(row, rowKey);
    if (seen.has(identity))
      throw new Error(
        `spa-table row_key ${JSON.stringify(rowKey)} contains duplicate value ${JSON.stringify(row[rowKey])}`
      );
    seen.add(identity);
    return [identity, row];
  });
}
function updateTableRow(tr, row, cols) {
  while (tr.cells.length < cols.length) tr.insertCell();
  while (tr.cells.length > cols.length) tr.deleteCell(-1);
  cols.forEach((column, i) => tableCell(tr.cells[i], row[column.key]));
}
if (typeof customElements !== "undefined" && !customElements.get("spa-table")) {
  customElements.define(
    "spa-table",
    class extends HTMLElement {
      cols = null;
      data = [];
      key = null;
      renderedCols = [];
      root;
      constructor() {
        super();
        this.root = this.attachShadow({ mode: "open" });
        const style = document.createElement("style");
        style.textContent = TABLE_CSS;
        this.root.append(style);
        this.render(true);
      }
      set columns(v) {
        this.cols = v;
        this.render(true);
      }
      get columns() {
        return this.cols;
      }
      set rowKey(v) {
        const next = v == null ? null : String(v);
        if (next === this.key) return;
        this.key = next;
        this.render(true);
      }
      get rowKey() {
        return this.key;
      }
      set rows(v) {
        this.data = Array.isArray(v) ? v : [];
        this.render();
      }
      get rows() {
        return this.data;
      }
      reconcileRows(tbody, cols) {
        const rows = keyedRows(this.data, this.key);
        const existing = new Map(
          [...tbody.rows].map((tr) => [tr.dataset.spadayRowKey, tr])
        );
        for (const [identity, row] of rows) {
          const tr = existing.get(identity) ?? document.createElement("tr");
          tr.dataset.spadayRowKey = identity;
          updateTableRow(tr, row, cols);
          tbody.append(tr);
          existing.delete(identity);
        }
        for (const tr of existing.values()) tr.remove();
      }
      render(force = false) {
        const cols = tableColumns(this.cols, this.data);
        const old = this.root.querySelector("table");
        if (old && this.key !== null && !force && sameColumns(cols, this.renderedCols)) {
          this.reconcileRows(old.tBodies[0], cols);
          return;
        }
        const table = document.createElement("table");
        const hr = table.createTHead().insertRow();
        for (const c of cols) {
          const th = document.createElement("th");
          th.textContent = c.label;
          hr.append(th);
        }
        const tbody = table.createTBody();
        if (this.key !== null) this.reconcileRows(tbody, cols);
        else
          for (const row of this.data) {
            const tr = tbody.insertRow();
            updateTableRow(tr, row, cols);
          }
        if (old) old.replaceWith(table);
        else this.root.append(table);
        this.renderedCols = cols;
      }
    }
  );
}

// src/ts/index.ts
async function init(moduleOrPath) {
  await __wbg_init(moduleOrPath);
  markReady();
}
var diff2 = (oldTree, newTree) => diff(oldTree, newTree);
var apply2 = (root, patch) => apply(root, patch);
var encodeFrame = (payload, modelType, kind, rev, codec = "application/json") => encode_frame(payload, modelType, kind, rev, codec);
var decodeFrame = (frame) => decode_frame(frame);
export {
  SHELL_TAGS,
  Scope,
  Store,
  apply2 as apply,
  applyPatch,
  connectStore,
  connectWorker,
  decodeFrame,
  diff2 as diff,
  encodeFrame,
  hydrate,
  init,
  interpret2 as interpret,
  mount,
  parseCem,
  registerHandler,
  registry,
  tag,
  untag,
  spaday_exports as wasm
};
//# sourceMappingURL=index.js.map
