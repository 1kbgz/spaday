// src/ts/examples/gateway.ts
import { registerHandler } from "/js/dist/esm/index.js";
registerHandler("clear-blotter", async () => {
  await fetch("/api/clear", { method: "POST" });
  const ws = document.querySelector("perspective-panel perspective-workspace");
  if (!ws) return;
  for (const v of ws.querySelectorAll("perspective-viewer")) {
    const viewer = v;
    for (let i = 0; i < 60 && await (await viewer.getView()).num_rows() > 0; i++)
      await new Promise((r) => setTimeout(r, 50));
    await viewer.restore(await viewer.save());
  }
  const status = document.getElementById("status");
  if (status) status.textContent = "cleared";
});
//# sourceMappingURL=gateway.js.map
