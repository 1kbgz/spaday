/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const apply: (a: number, b: number, c: number, d: number) => [number, number, number, number];
export const decode_frame: (a: number, b: number) => [number, number, number, number];
export const diff: (a: number, b: number, c: number, d: number) => [number, number, number, number];
export const encode_frame: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number) => [number, number, number, number];
export const interpret: (a: number, b: number, c: any) => [number, number];
export const parse_cem: (a: number, b: number) => [number, number, number, number];
export const wasm_bindgen_4b6145b5e397c687___convert__closures_____invoke___wasm_bindgen_4b6145b5e397c687___JsValue__core_f0fd674eaa06beef___result__Result_____wasm_bindgen_4b6145b5e397c687___JsError___true_: (a: number, b: number, c: any) => [number, number];
export const __wbindgen_malloc: (a: number, b: number) => number;
export const __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
export const __wbindgen_exn_store: (a: number) => void;
export const __externref_table_alloc: () => number;
export const __wbindgen_externrefs: WebAssembly.Table;
export const __wbindgen_destroy_closure: (a: number, b: number) => void;
export const __externref_table_dealloc: (a: number) => void;
export const __wbindgen_free: (a: number, b: number, c: number) => void;
export const __wbindgen_start: () => void;
