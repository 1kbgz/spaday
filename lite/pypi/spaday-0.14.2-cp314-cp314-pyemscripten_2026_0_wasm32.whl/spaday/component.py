"""The authoring base for spaday components.

A :class:`Component` is a Python object that builds one node of the spaday component tree — a tag, an
optional reconciliation key, props, and child slots — and serializes to the JSON wire form the Rust
core's ``diff``/``apply`` understand. The typed component classes generated from a Custom Elements
Manifest (see :mod:`spaday.cem`) subclass this and expose each element's attributes as typed keyword
arguments.

Behavior is attached with :meth:`Component.on` — the declarative action DSL (see :mod:`spaday.actions`):
the runtime interprets the action in the browser on the DOM event, with no round-trip to Python.
"""

from __future__ import annotations

import base64
import json
import re
from functools import lru_cache
from typing import Any, ClassVar, Union

from typing_extensions import Self

from .actions import Action, Expr
from .catalog import ComponentSchema, PropertySchema
from .schema import validate_action, validate_binding, validate_effect, validate_readiness

#: The conventional name of a component's unnamed (default) slot (matches the Rust core).
DEFAULT_SLOT = "default"

#: A child is a Component, an already-built node dict, or a string (which becomes a text node).
Child = Union["Component", dict, str]


def _attr_name(name: str) -> str:
    """A Python kwarg → its attribute name: drop one trailing underscore so reserved words work
    (``class_`` → ``class``, ``for_`` → ``for``)."""
    return name.removesuffix("_")


def _snake_name(name: str) -> str:
    """A camelCase prop name → its snake_case spelling (``maxLabelWidth`` → ``max_label_width``)."""
    return re.sub(r"(?<=[a-z0-9])(?=[A-Z])|(?<=[A-Z])(?=[A-Z][a-z])", "_", name).lower()


#: tag -> schema for every imported schema-carrying class (validate uses it for dict trees)
_SCHEMAS_BY_TAG: dict[str, ComponentSchema] = {}

#: Generic props the runtime sets on any element, so they pass the unknown-prop check everywhere.
_GLOBAL_PROPS = {"id", "class", "style", "slot", "part", "title", "role", "hidden", "tabindex", "textContent"}
_GLOBAL_PREFIXES = ("data-", "aria-", "attr:")
#: Native elements with a writable ``text`` DOM property. Other native elements need ``textContent``.
_TEXT_PROP_TAGS = {"a", "option", "script", "title"}


def _check_text_binding_target(tag: str, schema: ComponentSchema | None, prop: str) -> None:
    if prop == "text" and schema is None and "-" not in tag and tag not in _TEXT_PROP_TAGS:
        raise ValueError(f"<{tag}> has no 'text' DOM property; use .text(...) or bind 'textContent'")


@lru_cache(maxsize=None)
def _settable(schema: ComponentSchema) -> tuple[PropertySchema, ...]:
    """Every input a schema describes: its attributes and its property-only fields. Both are set the
    same way — as a keyword on the component — so both take the same aliasing and kind checks."""
    return schema.props + schema.fields


@lru_cache(maxsize=None)
def _prop_aliases(schema: ComponentSchema) -> dict[str, str]:
    """snake_case spelling → canonical name, for schema props and fields where the two spellings differ."""
    names = {prop.name for prop in _settable(schema)}
    aliases: dict[str, str] = {}
    for prop in _settable(schema):
        snake = _snake_name(prop.name)
        if snake != prop.name and snake not in names:
            aliases.setdefault(snake, prop.name)
    return aliases


def _unknown_prop(schema: ComponentSchema, tag: str, name: str) -> str | None:
    """The problem text for a keyword ``schema`` does not describe, or ``None`` when the name is fine.

    One definition of "accepted name", shared by the strict constructor and :func:`spaday.validate`:
    the schema's attributes and property-only fields, plus the generic props the runtime sets on any
    element. A name that is the snake_case spelling of a real one carries a did-you-mean hint.
    """
    known = {prop.name for prop in _settable(schema)}
    if name in known or name in _GLOBAL_PROPS or name.startswith(_GLOBAL_PREFIXES):
        return None
    hint = next((p for p in sorted(known) if _snake_name(p) == name), None)
    return f"<{tag}> unknown prop {name!r}" + (f" (did you mean {hint!r}?)" if hint else "")


def _tag(value: Any) -> Any:
    """Encode a plain Python value as the core's externally-tagged ``Value``."""
    if value is None:
        return "Null"
    if isinstance(value, bool):
        return {"Bool": value}
    if isinstance(value, int):
        return {"Int": value}
    if isinstance(value, float):
        return {"Float": value}
    if isinstance(value, str):
        return {"Str": value}
    if isinstance(value, (bytes, bytearray, memoryview)):
        return {"Bytes": base64.b64encode(bytes(value)).decode("ascii")}
    if isinstance(value, (list, tuple)):
        return {"List": [_tag(v) for v in value]}
    if isinstance(value, dict):
        return {"Map": {str(k): _tag(v) for k, v in value.items()}}
    raise TypeError(f"unsupported prop value type for spaday: {type(value)!r}")


def _as_node(child: Component | dict) -> dict:
    return child.to_node() if isinstance(child, Component) else child


# The Python shape a catalog prop kind demands of a *literal* value. `json` is absent on purpose: the
# catalog maps every complex/unknown type (lists, objects, mixed unions, untyped props) to it, so no
# literal shape can be ruled out. Reactive bindings/computed values are dynamic and never checked.
_KIND_TYPES: dict[str, type | tuple[type, ...]] = {
    "string": str,
    "enum": str,
    "boolean": bool,
    "number": (int, float),
}


def _declared_container(type_text: str | None) -> type | None:
    """The Python container a declared type unambiguously calls for, or ``None`` when it is not obvious.

    A `json` prop's declared type is the only description of its shape, and the two mistakes worth
    catching are a matrix where an object belongs and the reverse — the browser reports those as a
    setter throwing far from the mistake. Only the spellings that can mean nothing else are read: an
    array (`T[]`, `Array<T>`) and an object (`{…}`, `Record<…>`). A named type is deliberately not read:
    an alias can name either, so `HeatmapData` says nothing a check could rely on — the name is carried
    in the schema so an author who knows their own types can assert on it.
    """
    if not type_text or "|" in type_text:  # a union may accept several shapes
        return None
    if type_text.endswith("[]") or type_text.startswith(("Array<", "ReadonlyArray<")):
        return list
    if type_text.startswith(("{", "Record<")):
        return dict
    return None


def _css_name(name: str) -> str:
    """A Python kwarg → its CSS name: drop one trailing ``_``, then ``_`` → ``-`` (``font_size`` → ``font-size``)."""
    name = name.removesuffix("_")
    return name.replace("_", "-")


class Component:
    """Base for a node in the spaday component tree.

    Author it two equivalent ways: nest children **positionally** in the constructor and set generic
    props as keywords — ``App(Nav("title"), Body(...), id="root")`` — or build it up fluently with
    ``.child()`` / ``.prop()``. A string child becomes a text node. Subclasses set the class attribute
    ``tag`` and forward their typed props via ``props=`` (only the ones the author set — ``None`` means
    "leave the element's own default"). CEM-generated subclasses also set the class-level ``schema``
    used by component catalogs; hand-authored catalog components may set it explicitly.
    """

    tag: str = ""
    schema: ClassVar[ComponentSchema | None] = None
    #: Reject unknown keywords at construction (see :meth:`set_strict_props`). Off by default.
    strict_props: ClassVar[bool] = False

    def __init_subclass__(cls, **kwargs: Any) -> None:
        super().__init_subclass__(**kwargs)
        # schema-carrying classes register by tag, so `validate` can check props on serialized
        # dict trees too (a node dict carries no schema of its own)
        if cls.schema is not None and cls.tag:
            _SCHEMAS_BY_TAG[cls.tag] = cls.schema

    def __init__(self, *children: Child, key: str | None = None, props: dict[str, Any] | None = None, **attrs: Any) -> None:
        self._key = key
        merged = dict(props or {})  # typed props (from a subclass) + generic keyword props (id, style, …)
        generic = {_attr_name(k): v for k, v in attrs.items()}
        if type(self).schema is not None and generic:
            # a schema-carrying class also accepts the snake_case spelling of each camelCase prop
            # (`max_label_width=` lands as prop `maxLabelWidth`); both spellings at once is ambiguous
            aliases = _prop_aliases(type(self).schema)
            for name in [n for n in generic if n in aliases and generic[n] is not None]:
                canonical = aliases[name]
                if generic.get(canonical) is not None or merged.get(canonical) is not None:
                    raise TypeError(f"<{self.tag}> prop {canonical!r} passed under both spellings ({name!r} and {canonical!r})")
                generic[canonical] = generic.pop(name)
        merged.update(generic)
        self._props: dict[str, Any] = {k: v for k, v in merged.items() if v is not None}
        if type(self).schema is not None:
            if type(self).strict_props:
                self._check_prop_names()
                self._check_prop_shapes()
            self._check_prop_kinds()
        self._slots: dict[str, list[Component | dict]] = {}
        self._events: dict[str, dict] = {}
        self._event_options: dict[str, dict[str, bool]] = {}
        self._bindings: dict[str, dict] = {}
        self._effects: dict[str, dict] = {}
        self._readiness: dict | None = None
        self._style: dict[str, str] = {}  # inline CSS declarations + custom properties (theming)
        self._classes: list[str] = []  # CSS classes (variants / states)
        self.child(*children)

    @classmethod
    def set_strict_props(cls, strict: bool = True) -> None:
        """Make unknown keyword arguments raise at construction, for ``cls`` and its subclasses.

        Off by default: a manifest describes an element's inputs approximately (see
        :attr:`ComponentSchema.fields`), so an unrecognized keyword is reported by
        :func:`spaday.validate` over a built tree rather than assumed to be a mistake. Turn it on where
        the earlier error is worth that risk, at whichever scope fits — the whole catalog
        (``Component.set_strict_props()``), one package's components
        (``WaButton.set_strict_props()``, which works on a generated catalog you don't own), or off
        again for a single class the manifest describes badly (``WaSelect.set_strict_props(False)``).
        A class that sets it explicitly keeps that setting when a base class is toggled later, so a
        per-class opt-out survives turning the catalog strict. Classes without a ``schema`` have
        nothing to check and are unaffected.

        Only constructor keywords are checked; :meth:`prop` stays the explicit escape hatch for an
        attribute the manifest does not describe.
        """
        cls.strict_props = strict

    @classmethod
    def retag(cls, tag: str) -> type["Component"]:
        """A subclass of this component bound to a different custom element name.

        Use it when an application ships its own element implementing the same contract and wants
        this class's authoring surface — props, bindings, actions, catalog schema — pointed at that
        element instead::

            MyGrid = PerspectivePanel.retag("my-data-grid")

        The tag is carried into the class's ``schema`` as well, which
        :class:`~spaday.packages.ComponentPackage` requires to agree with ``tag``, so the result can
        go straight into a package descriptor. The new tag registers for dict-tree validation like
        any other schema-carrying class.
        """
        if not tag:
            raise ValueError("retag requires a tag")
        schema = cls.schema.model_copy(update={"tag": tag}) if cls.schema is not None else None
        return type(cls.__name__, (cls,), {"tag": tag, "schema": schema})

    def _check_prop_names(self) -> None:
        """Reject keywords the class's catalog ``schema`` does not describe (opt-in; see
        :meth:`set_strict_props`). Reports every unknown name at once, by the same rules and in the
        same words :func:`spaday.validate` uses on a built tree."""
        assert self.schema is not None
        problems = [problem for name in self._props if (problem := _unknown_prop(self.schema, self.tag, name))]
        if problems:
            raise TypeError("; ".join(problems))

    def _check_prop_shapes(self) -> None:
        """Reject a ``json`` prop whose literal contradicts its declared type (opt-in; see
        :meth:`set_strict_props`). The shape half of :meth:`_check_prop_kinds`: a `json` kind rules out
        no Python value, but a type declared as an array or an object rules out the other one."""
        declared = {prop.name: prop.type_text for prop in _settable(self.schema) if prop.kind == "json"}
        for name, value in self._props.items():
            expected = _declared_container(declared.get(name))
            if expected is None:
                continue
            if not isinstance(value, expected) and not (expected is list and isinstance(value, tuple)):
                raise TypeError(f"<{self.tag}> prop {name!r} expects {declared[name]}, got {value!r} ({type(value).__name__})")

    def _check_prop_kinds(self) -> None:
        """Reject a literal prop value that contradicts the class's catalog ``schema`` kind.

        The authoring-time half of prop validation (the browser doesn't ship the catalog): a plain
        value of the wrong shape — e.g. a ``str`` for a ``number`` prop — fails here with the
        component and prop named, instead of surfacing later as an opaque component error. Only
        kinds with an unambiguous Python shape are checked (see ``_KIND_TYPES``); ``json`` props and
        props outside the schema (``id``, ``style``, …) pass through.
        """
        kinds = {prop.name: prop.kind for prop in _settable(self.schema)}
        for name, value in self._props.items():
            expected = _KIND_TYPES.get(kinds.get(name, ""))
            if expected is None:
                continue
            if not isinstance(value, expected) or (kinds[name] == "number" and isinstance(value, bool)):
                raise TypeError(f"<{self.tag}> prop {name!r} expects kind {kinds[name]!r}, got {value!r} ({type(value).__name__})")

    def key(self, key: str) -> Self:
        """Set the reconciliation key (for keyed child diffing)."""
        self._key = key
        return self

    def child(self, *nodes: Child) -> Self:
        """Append one or more children to the default slot (a string child becomes a text node)."""
        for node in nodes:
            self.child_in(DEFAULT_SLOT, node)
        return self

    def child_in(self, slot: str, node: Child) -> Self:
        """Append a child to a named slot (a string becomes a ``<span>`` text node)."""
        if not isinstance(node, (Component, dict, str)):
            raise TypeError(f"child must be a Component, node dict, or string, got {type(node).__name__}")
        self._slots.setdefault(slot, []).append(element("span", textContent=node) if isinstance(node, str) else node)
        return self

    def text(self, value: str | Expr) -> Self:
        """Set the element's literal or reactive text content (e.g. a button or option label).

        Text is set as the ``textContent`` DOM property by the runtime, so this is for leaf elements
        whose label *is* their text (don't combine it with child nodes). An expression such as
        ``item("name")`` becomes a computed binding.
        """
        if isinstance(value, Expr):
            return self.compute("textContent", value)
        self._props["textContent"] = value
        return self

    def attr(self, name: str, value: str | int | float | bool | None) -> Self:
        """Set an HTML attribute explicitly. True means present; False/None remove it.

        Uses the shared tree's ``attr:`` target prefix, bypassing DOM property setters.
        """
        if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_.:-]*", name):
            raise ValueError(f"invalid attribute name: {name!r}")
        if value is not None and not isinstance(value, (str, int, float, bool)):
            raise TypeError("attribute values must be scalar or None")
        self._props[f"attr:{name}"] = value
        return self

    def bind_attr(self, name: str, field: str) -> Self:
        """Keep an HTML attribute synchronized with a store field (one-way)."""
        if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_.:-]*", name):
            raise ValueError(f"invalid attribute name: {name!r}")
        return self.bind(f"attr:{name}", field)

    def prop(self, name: str, value: Any) -> Self:
        """Set a literal prop or compute it reactively from an expression.

        Expressions use the same one-way binding as :meth:`compute`. Literal values retain
        their existing behavior, including leaving the prop unchanged when passed ``None``.
        """
        if isinstance(value, Expr):
            return self.compute(name, value)
        if value is not None:
            self._props[name] = value
        return self

    def style(self, **decls: Any) -> Self:
        """Set inline CSS declarations, e.g. ``.style(padding="1rem", font_size="2rem")``.

        Keys are kebab-cased (``font_size`` → ``font-size``; a trailing ``_`` is dropped so reserved
        words work, ``float_`` → ``float``). Composes with :meth:`css` and any literal ``style`` prop.
        """
        self._style.update({_css_name(k): str(v) for k, v in decls.items() if v is not None})
        return self

    def css(self, **variables: Any) -> Self:
        """Set CSS **custom properties** — the theming knob, e.g. ``.css(background_color="navy")`` →
        ``--background-color: navy``. This is how a web component's documented `--*` theme tokens are
        set from Python (per component), and how the ``spa-*`` shell is re-themed at the app level
        (``App().css(spa_surface="#111", spa_border="#333")`` cascades to the whole shell). WebAwesome's
        own custom-property tokens are set the same way. See :mod:`spaday.theme`.
        """
        self._style.update({"--" + _css_name(k): str(v) for k, v in variables.items() if v is not None})
        return self

    def classes(self, *names: str) -> Self:
        """Add CSS classes (component variants / theme states), e.g. ``.classes("wa-dark")``."""
        self._classes.extend(n for n in names if n)
        return self

    def effect(self, name: str, action: Action | dict, *, watch: list[str] | tuple[str, ...], initial: bool = False) -> Self:
        """Run an action when watched store fields change; cancel its previous invocation.

        ``initial=True`` also runs after mounting. Effects are disposed with this component.
        Updates in one synchronous turn coalesce into one invocation with the latest values.
        """
        if not isinstance(name, str) or not name.strip():
            raise ValueError("effect name must be a nonempty string")
        self._effects[name] = validate_effect(
            {
                "watch": watch,
                "initial": initial,
                "action": action.to_dict() if isinstance(action, Action) else action,
            }
        )
        return self

    def ready(
        self,
        when: Expr | bool,
        *,
        result: str | None = None,
        active: Expr | bool = True,
        error: Expr | str | None = None,
        elements: list[str] | tuple[str, ...] = (),
        timeout: int = 10000,
    ) -> Self:
        """Track this view's readiness; optionally publish ``{status, error}`` to ``result``.

        Always emits ``spaday:readiness`` events, including without a store or result field.
        Status is loading, ready, error, or idle when inactive. Timeout errors recover when
        data and components become ready. This does not block or dispose other views.
        """
        from .actions import lit

        self._readiness = validate_readiness(
            {
                "when": (when if isinstance(when, Expr) else lit(when)).to_dict(),
                "active": (active if isinstance(active, Expr) else lit(active)).to_dict(),
                "error": (error if isinstance(error, Expr) else lit(error)).to_dict(),
                "result": result,
                "elements": elements,
                "timeout": timeout,
            }
        )
        return self

    def on(self, event: str, action: Action, *, capture: bool | None = None, once: bool | None = None, passive: bool | None = None) -> Self:
        """Bind a declarative :class:`~spaday.actions.Action` to a DOM event (e.g. ``"click"``).

        The action is serialized as data and interpreted in the browser when the event fires — no
        round-trip to Python.

        ``capture``, ``once`` and ``passive`` are optional DOM listener options. ``None`` preserves
        the browser default; explicit ``False`` is retained. Capture observes non-bubbling events
        such as native ``invalid`` within the same tree, not non-composed events inside a shadow root.
        Rebinding this event replaces its action and options. A replaced once-only listener is armed again.
        """
        if not isinstance(action, Action):
            raise TypeError(f"event action must be an Action, got {type(action).__name__}")
        return self._on(event, action.to_dict(), capture=capture, once=once, passive=passive)

    def on_wire(self, event: str, action: object, *, capture: bool | None = None, once: bool | None = None, passive: bool | None = None) -> Self:
        """Bind already-serialized action data after validating it with the shared core model.

        Editors and source adapters use this when behavior starts as structured data rather than a
        Python :class:`~spaday.actions.Action` instance.
        """
        return self._on(event, validate_action(action), capture=capture, once=once, passive=passive)

    def _on(self, event: str, action: dict, *, capture: bool | None, once: bool | None, passive: bool | None) -> Self:
        options = {name: value for name, value in {"capture": capture, "once": once, "passive": passive}.items() if value is not None}
        if any(not isinstance(value, bool) for value in options.values()):
            raise TypeError("listener options must be bool or None")
        self._events[event] = action
        if options:
            self._event_options[event] = options
        else:
            self._event_options.pop(event, None)
        return self

    def bind_wire(self, prop: str, binding: object) -> Self:
        """Attach already-serialized binding data after shared-core validation."""
        self._check_text_binding(prop)
        self._bindings[prop] = validate_binding(binding)
        return self

    def bind(
        self,
        prop: str,
        field: str | Expr,
        *,
        mode: str = "one-way",
        event: str | None = None,
        methods: tuple[str, str] | None = None,
        state: str | None = None,
        defer: bool = False,
        codec: str | None = None,
        encode: str | None = None,
    ) -> Self:
        """Reactively bind a ``prop`` to a state ``field`` in the runtime's signal store.

        ``mode="one-way"`` keeps the prop in sync with the field; ``"two-way"`` also writes the field
        back when the control changes (for value-like controls). The binding is data interpreted in the
        browser — the field's value flows to the prop with no round-trip to Python.
        ``field`` also accepts ``item("label")`` or ``scope("row.label")`` inside an ``Each``.
        Item writes resolve the current record by key; they cannot change that key. Collections
        derived from arbitrary expressions and server-windowed collections remain read-only.

        A two-way binding writes back on ``change`` / ``input``; ``event`` names the event instead, for
        a control that reports its changes otherwise (a Lion control's ``model-value-changed``).
        ``methods`` — ``("open", "close")`` — drives the prop by calling those methods on the element
        as the field turns truthy / falsy instead of setting it, for an overlay that opens by method
        (``bind("open", "confirm", mode="two-way", event="close", methods=("showModal", "close"))`` on
        a ``<dialog>``); the prop then names the element's own state, read back on ``event``.
        ``state`` names a different property, including a dotted path, when that readable state lives
        below the element (for example ``"dialog.open"`` on a wrapper around ``<dialog>``).
        ``defer=True`` coalesces property writes until the next animation frame, after the element is
        connected and its children have been assigned.
        ``codec="number"`` converts an empty value to ``None`` and other values to numbers on
        write-back; ``"json"`` JSON-encodes values sent to the element and decodes them on return.
        ``encode="string"`` stringifies values sent to the element without changing how its readable
        state is decoded.
        """
        if mode not in ("one-way", "two-way"):
            raise ValueError(f"bind mode must be 'one-way' or 'two-way', not {mode!r}")
        self._check_text_binding(prop)
        binding: dict[str, Any]
        if isinstance(field, Expr):
            reference = field.to_dict()
            if reference.get("expr") not in ("field", "item", "scope"):
                raise ValueError("bind requires a field, item, or scope reference; use compute for derived values")
            binding = {"field": reference["name"], "mode": mode} if reference["expr"] == "field" else {"compute": reference, "mode": mode}
        else:
            binding = {"field": field, "mode": mode}
        if event is not None:
            binding["event"] = event
        if methods is not None:
            if len(methods) != 2 or not all(isinstance(m, str) and m for m in methods):
                raise ValueError("bind methods must be an (open, close) pair of method names")
            binding["methods"] = list(methods)
        if state is not None:
            if not isinstance(state, str) or not state or any(not part for part in state.split(".")):
                raise ValueError("bind state must be a non-empty dotted property path")
            binding["state"] = state
        if defer:
            binding["defer"] = True
        if codec not in (None, "number", "json"):
            raise ValueError(f"binding codec must be 'number' or 'json', not {codec!r}")
        if codec is not None:
            binding["codec"] = codec
        if encode not in (None, "string"):
            raise ValueError(f"binding encode must be 'string', not {encode!r}")
        if codec == "json" and encode is not None:
            raise ValueError("binding encode cannot be combined with the json codec")
        if encode is not None:
            binding["encode"] = encode
        self._bindings[prop] = validate_binding(binding)
        return self

    def compute(self, prop: str, expr: Expr) -> Self:
        """Reactively set ``prop`` to a value *computed* from state fields (one-way).

        ``expr`` is a field expression (:func:`~spaday.actions.field` / ``eq`` / ``not_`` / ``all_`` /
        ``any_`` / ``lit`` / ``item`` / ``scope``) evaluated in the browser and recomputed whenever any
        global field or repeater scope it reads changes, e.g. ``compute("disabled", not_(field("enabled")))``.
        """
        if not isinstance(expr, Expr):
            raise TypeError(f"computed binding must use an Expr, got {type(expr).__name__}")
        self._check_text_binding(prop)
        self._bindings[prop] = {"compute": expr.to_dict(), "mode": "one-way"}
        return self

    def _check_text_binding(self, prop: str) -> None:
        _check_text_binding_target(self.tag, type(self).schema, prop)

    def bind_root_class(self, name: str, field: str) -> Self:
        """Toggle a CSS class on the document root (``<html>``) from a boolean reactive state ``field``.

        The escape hatch for *page-level* theming that lives outside the component tree — most notably
        WebAwesome's ``wa-dark``: ``App(...).bind_root_class("wa-dark", "dark")`` makes a switch bound to
        a ``dark`` field re-theme the whole page (the rest follows via CSS tokens; canvas widgets that
        can't read a class take a ``.compute("theme", cond(field("dark"), "dark", "light"))`` instead).
        One-way (the field drives the class); active only when mounted with a signal ``Store``.
        """
        self._bindings[f"root-class:{name}"] = {"field": field, "mode": "one-way"}
        return self

    def bind_root_attr(self, name: str, field: str) -> Self:
        """Set an attribute on the document root (``<html>``) from a reactive state ``field``.

        The attribute counterpart to :meth:`bind_root_class`, for the page-level state a class cannot
        carry: a theme selector whose *value* is matched (``:root[data-density='comfortable']``) needs an
        attribute, since a class carries no value and enumerated values would need mutually exclusive
        naming plus removal logic. The field's value is written as the runtime writes any attribute —
        ``None``/``False`` remove it, ``True`` and ``""`` give the bare form (``data-vivid``), anything
        else is stringified — so one binding covers both enumerated and boolean root state.
        One-way (the field drives the attribute); active only when mounted with a signal ``Store``.
        """
        if name in ("class", "style"):
            raise ValueError(f"bind_root_attr cannot set {name!r} on the document root (use bind_root_class / theme tokens)")
        self._bindings[f"root-attr:{name}"] = {"field": field, "mode": "one-way"}
        return self

    def _final_props(self) -> dict[str, Any]:
        """Props with theming folded in: ``style``/``class`` merged from :meth:`style`/:meth:`css`/
        :meth:`classes` (after any literal ``style``/``class`` prop)."""
        props = dict(self._props)
        if self._style:
            decls = "; ".join(f"{k}: {v}" for k, v in self._style.items())
            props["style"] = f"{props['style']}; {decls}" if props.get("style") else decls
        if self._classes:
            names = " ".join(self._classes)
            props["class"] = f"{props['class']} {names}" if props.get("class") else names
        return props

    def to_node(self) -> dict:
        """The node as the core's JSON-ready dict (empty fields omitted, like the Rust core)."""
        node: dict = {"tag": self.tag}
        if self._key is not None:
            node["key"] = self._key
        props = self._final_props()
        if props:
            node["props"] = {name: _tag(v) for name, v in props.items()}
        if self._slots:
            node["slots"] = {slot: [_as_node(c) for c in children] for slot, children in self._slots.items()}
        if self._events:
            # actions are the core's own DSL wire form (see spaday.actions) — plain, not a tagged Value
            node["events"] = dict(self._events)
        if self._event_options:
            node["event_options"] = {name: dict(options) for name, options in self._event_options.items()}
        if self._bindings:
            node["bindings"] = dict(self._bindings)
        if self._effects:
            node["effects"] = dict(self._effects)
        if self._readiness is not None:
            node["readiness"] = dict(self._readiness)
        return node

    def to_json(self) -> str:
        """The node serialized for the core's ``diff``/``apply``."""
        return json.dumps(self.to_node())


def element(tag: str, *children: Child, key: str | None = None, **props: Any) -> Component:
    """Build a plain element (e.g. a ``div`` container) for structure a typed component doesn't cover.

    Children nest positionally; a prop name with a trailing underscore is de-escaped so reserved words
    work (``class_`` → ``class``). e.g. ``element("div", Strong("hi"), id="root", class_="card")``.
    """
    normalized = {_attr_name(k): v for k, v in props.items()}
    if "text" in normalized:
        _check_text_binding_target(tag, None, "text")
    node = Component(*children, key=key, props=normalized)
    node.tag = tag
    return node


def Text(text: str | Expr, **props: Any) -> Component:
    """An inline text node — a ``<span>``. ``Row("Echo: ", echo)`` does the same via a bare string child."""
    return element("span", **props).text(text)


def Strong(text: str | Expr, **props: Any) -> Component:
    """Bold inline text — a ``<strong>``."""
    return element("strong", **props).text(text)


def Paragraph(text: str | Expr, **props: Any) -> Component:
    """A paragraph — a ``<p>``."""
    return element("p", **props).text(text)
