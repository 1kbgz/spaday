/* tslint:disable */
/* eslint-disable */

/**
 * A JSON control frame with native binary attachments.
 */
export class BufferFrame {
    free(): void;
    [Symbol.dispose](): void;
    buffer(index: number): Uint8Array;
    count(): number;
    static decode(data: Uint8Array, codec: string): BufferFrame;
    encode(codec: string): Uint8Array;
    static from_json(json: string): BufferFrame;
    constructor(header: string);
    push(buffer: Uint8Array): void;
    to_json(): string;
    readonly header: string;
}

/**
 * Shared revision and proposal reducer for a language-level client adapter.
 */
export class ClientState {
    free(): void;
    [Symbol.dispose](): void;
    abandon(proposal: string): boolean;
    commit(effect_json: string): void;
    disconnect(): string;
    constructor();
    pending(): string;
    prepare(message_json: string): string;
    proposal(id: bigint, ops_json: string, proposal?: string | null): string;
    revisions(): string;
    type_name(id: bigint): string | undefined;
}

/**
 * Schema-directed CRDT reducer backed by the shared core.
 */
export class CrdtDocument {
    free(): void;
    [Symbol.dispose](): void;
    apply(ops_json: string): string;
    compact(frontier_json: string): number;
    diff(path_json: string, value_json: string): string;
    static from_state(spec_json: string, state_json: string, replica: string): CrdtDocument;
    member_key(path_json: string, value_json: string): string;
    mutate(mutations_json: string): string;
    constructor(spec_json: string, value_json: string, replica: string);
    state(): string;
    value(): string;
}

/**
 * Single-server authority for one model's client-owned fields.
 */
export class FieldAuthority {
    free(): void;
    [Symbol.dispose](): void;
    acknowledge(connection: string, epoch: bigint, command: bigint): void;
    close(connection: string): boolean;
    command(field: string, value: string): bigint;
    commit(sequence: bigint): void;
    grant(connection: string): string;
    constructor(id: bigint, fields: string, command_cap: number);
    next_command(): string | undefined;
    open(connection: string): string;
    owner(): string | undefined;
    validate(connection: string, message: string): boolean;
}

/**
 * Client-side ownership classification and sequence generation.
 */
export class OwnedFields {
    free(): void;
    [Symbol.dispose](): void;
    classify(id: bigint, ops: string): boolean;
    disconnect(): void;
    drain(): string;
    edit(id: bigint, ops: string): string;
    constructor();
    owns(id: bigint, field: string): boolean;
    queue(id: bigint, ops: string): string;
    receive(message: string): boolean;
    server_ops(id: bigint, ops: string): string;
}

/**
 * Bounded per-model replay with shared binary attachments.
 */
export class ReplayLog {
    free(): void;
    [Symbol.dispose](): void;
    append(patch: string): void;
    blobs(): number;
    bytes(): number;
    count(): number;
    constructor(cap: number, max_bytes: number, blob_threshold: number);
    since(rev: bigint, current: bigint): string | undefined;
}

/**
 * In-process model store: host / mutate → patch / apply / snapshot.
 */
export class Store {
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Apply a JSON patch to a mirrored model; returns whether the id was known.
     */
    apply(id: bigint, patch_json: string): boolean;
    field(id: bigint, name: string): string | undefined;
    /**
     * Host a model from its JSON; returns the assigned id.
     */
    host(type_name: string, value_json: string, list_keys?: string | null): bigint;
    /**
     * Replace a hosted model from JSON; returns the JSON patch (or `undefined` if id unknown).
     */
    mutate(id: bigint, value_json: string): string | undefined;
    constructor();
    revision(id: bigint): bigint | undefined;
    /**
     * `{"type_name":..,"rev":..,"value":..}` for a hosted model, or `undefined`.
     */
    snapshot(id: bigint): string | undefined;
}

/**
 * Apply a JSON-encoded patch to a JSON-encoded model, returning the JSON-encoded result.
 */
export function apply(value: string, patch: string): string;

/**
 * Convert CBOR bytes back to a JSON document.
 */
export function cbor_to_json(data: Uint8Array): string;

/**
 * Return the deterministic SHA-256 hash of a CRDT specification.
 */
export function crdt_spec_hash(json: string): string;

/**
 * Decode codec bytes back to a JSON-encoded model string.
 */
export function decode(data: Uint8Array): string;

/**
 * Decode bytes (produced by `codec`'s codec) back to a JSON-encoded model string.
 */
export function decode_as(data: Uint8Array, codec: string): string;

/**
 * Decode one built-in connection-codec payload as a typed live protocol message JSON string.
 */
export function decode_message(data: Uint8Array, codec: string): string;

/**
 * Diff two JSON-encoded models, returning the JSON-encoded patch.
 */
export function diff(old: string, _new: string, list_keys?: string | null): string;

/**
 * Encode a JSON-encoded model to codec bytes (a `Uint8Array` in JS).
 */
export function encode(value: string): Uint8Array;

/**
 * Encode a JSON-encoded model with the codec named by `codec` (e.g. `"application/msgpack"`).
 */
export function encode_as(value: string, codec: string): Uint8Array;

/**
 * Encode one JSON live protocol message with a built-in connection codec.
 */
export function encode_message(json: string, codec: string): Uint8Array;

/**
 * Convert an arbitrary JSON document to CBOR bytes (a `Uint8Array` in JS).
 */
export function json_to_cbor(json: string): Uint8Array;

/**
 * Convert an arbitrary JSON document to MessagePack bytes (a `Uint8Array` in JS).
 */
export function json_to_msgpack(json: string): Uint8Array;

/**
 * Convert MessagePack bytes back to a JSON document.
 */
export function msgpack_to_json(data: Uint8Array): string;

/**
 * Parse, validate, and deterministically serialize a CRDT specification.
 */
export function normalize_crdt_spec(json: string): string;

/**
 * Parse and serialize one typed live protocol message as compact JSON.
 */
export function normalize_message(json: string): string;

/**
 * Reject a peer hash that does not match the local CRDT specification.
 */
export function require_crdt_spec_hash(json: string, peer_hash: string): void;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly memory: WebAssembly.Memory;
    readonly __wbg_bufferframe_free: (a: number, b: number) => void;
    readonly __wbg_clientstate_free: (a: number, b: number) => void;
    readonly __wbg_crdtdocument_free: (a: number, b: number) => void;
    readonly __wbg_fieldauthority_free: (a: number, b: number) => void;
    readonly __wbg_ownedfields_free: (a: number, b: number) => void;
    readonly __wbg_replaylog_free: (a: number, b: number) => void;
    readonly __wbg_store_free: (a: number, b: number) => void;
    readonly apply: (a: number, b: number, c: number, d: number) => [number, number, number, number];
    readonly bufferframe_buffer: (a: number, b: number) => [number, number, number, number];
    readonly bufferframe_count: (a: number) => number;
    readonly bufferframe_decode: (a: number, b: number, c: number, d: number) => [number, number, number];
    readonly bufferframe_encode: (a: number, b: number, c: number) => [number, number, number, number];
    readonly bufferframe_from_json: (a: number, b: number) => [number, number, number];
    readonly bufferframe_header: (a: number) => [number, number];
    readonly bufferframe_new: (a: number, b: number) => number;
    readonly bufferframe_push: (a: number, b: number, c: number) => void;
    readonly bufferframe_to_json: (a: number) => [number, number, number, number];
    readonly cbor_to_json: (a: number, b: number) => [number, number, number, number];
    readonly clientstate_abandon: (a: number, b: number, c: number) => number;
    readonly clientstate_commit: (a: number, b: number, c: number) => [number, number];
    readonly clientstate_disconnect: (a: number) => [number, number, number, number];
    readonly clientstate_new: () => number;
    readonly clientstate_pending: (a: number) => [number, number, number, number];
    readonly clientstate_prepare: (a: number, b: number, c: number) => [number, number, number, number];
    readonly clientstate_proposal: (a: number, b: bigint, c: number, d: number, e: number, f: number) => [number, number, number, number];
    readonly clientstate_revisions: (a: number) => [number, number, number, number];
    readonly clientstate_type_name: (a: number, b: bigint) => [number, number];
    readonly crdt_spec_hash: (a: number, b: number) => [number, number, number, number];
    readonly crdtdocument_apply: (a: number, b: number, c: number) => [number, number, number, number];
    readonly crdtdocument_compact: (a: number, b: number, c: number) => [number, number, number];
    readonly crdtdocument_diff: (a: number, b: number, c: number, d: number, e: number) => [number, number, number, number];
    readonly crdtdocument_from_state: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number, number];
    readonly crdtdocument_member_key: (a: number, b: number, c: number, d: number, e: number) => [number, number, number, number];
    readonly crdtdocument_mutate: (a: number, b: number, c: number) => [number, number, number, number];
    readonly crdtdocument_new: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number, number];
    readonly crdtdocument_state: (a: number) => [number, number, number, number];
    readonly crdtdocument_value: (a: number) => [number, number, number, number];
    readonly decode: (a: number, b: number) => [number, number, number, number];
    readonly decode_as: (a: number, b: number, c: number, d: number) => [number, number, number, number];
    readonly decode_message: (a: number, b: number, c: number, d: number) => [number, number, number, number];
    readonly diff: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number, number, number];
    readonly encode: (a: number, b: number) => [number, number, number, number];
    readonly encode_as: (a: number, b: number, c: number, d: number) => [number, number, number, number];
    readonly encode_message: (a: number, b: number, c: number, d: number) => [number, number, number, number];
    readonly fieldauthority_acknowledge: (a: number, b: number, c: number, d: bigint, e: bigint) => [number, number];
    readonly fieldauthority_close: (a: number, b: number, c: number) => number;
    readonly fieldauthority_command: (a: number, b: number, c: number, d: number, e: number) => [bigint, number, number];
    readonly fieldauthority_commit: (a: number, b: bigint) => void;
    readonly fieldauthority_grant: (a: number, b: number, c: number) => [number, number, number, number];
    readonly fieldauthority_new: (a: bigint, b: number, c: number, d: number) => [number, number, number];
    readonly fieldauthority_next_command: (a: number) => [number, number, number, number];
    readonly fieldauthority_open: (a: number, b: number, c: number) => [number, number, number, number];
    readonly fieldauthority_owner: (a: number) => [number, number];
    readonly fieldauthority_validate: (a: number, b: number, c: number, d: number, e: number) => [number, number, number];
    readonly json_to_cbor: (a: number, b: number) => [number, number, number, number];
    readonly json_to_msgpack: (a: number, b: number) => [number, number, number, number];
    readonly msgpack_to_json: (a: number, b: number) => [number, number, number, number];
    readonly normalize_crdt_spec: (a: number, b: number) => [number, number, number, number];
    readonly normalize_message: (a: number, b: number) => [number, number, number, number];
    readonly ownedfields_classify: (a: number, b: bigint, c: number, d: number) => [number, number, number];
    readonly ownedfields_disconnect: (a: number) => void;
    readonly ownedfields_drain: (a: number) => [number, number, number, number];
    readonly ownedfields_edit: (a: number, b: bigint, c: number, d: number) => [number, number, number, number];
    readonly ownedfields_new: () => number;
    readonly ownedfields_owns: (a: number, b: bigint, c: number, d: number) => number;
    readonly ownedfields_queue: (a: number, b: bigint, c: number, d: number) => [number, number, number, number];
    readonly ownedfields_receive: (a: number, b: number, c: number) => [number, number, number];
    readonly ownedfields_server_ops: (a: number, b: bigint, c: number, d: number) => [number, number, number, number];
    readonly replaylog_append: (a: number, b: number, c: number) => [number, number];
    readonly replaylog_blobs: (a: number) => number;
    readonly replaylog_bytes: (a: number) => number;
    readonly replaylog_count: (a: number) => number;
    readonly replaylog_new: (a: number, b: number, c: number) => number;
    readonly replaylog_since: (a: number, b: bigint, c: bigint) => [number, number, number, number];
    readonly require_crdt_spec_hash: (a: number, b: number, c: number, d: number) => [number, number];
    readonly store_apply: (a: number, b: bigint, c: number, d: number) => [number, number, number];
    readonly store_field: (a: number, b: bigint, c: number, d: number) => [number, number];
    readonly store_host: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => [bigint, number, number];
    readonly store_mutate: (a: number, b: bigint, c: number, d: number) => [number, number, number, number];
    readonly store_new: () => number;
    readonly store_revision: (a: number, b: bigint) => [number, bigint];
    readonly store_snapshot: (a: number, b: bigint) => [number, number];
    readonly __wbindgen_externrefs: WebAssembly.Table;
    readonly __wbindgen_malloc: (a: number, b: number) => number;
    readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
    readonly __externref_table_dealloc: (a: number) => void;
    readonly __wbindgen_free: (a: number, b: number, c: number) => void;
    readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
