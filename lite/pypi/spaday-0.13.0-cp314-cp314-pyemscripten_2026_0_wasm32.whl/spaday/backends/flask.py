"""Flask (WSGI) backend.

- ``mount(app, page, *, prefix="", …)`` — add spaday's routes to an **existing** Flask app.
- ``serve(page, …) -> flask.Flask`` — create an app and ``mount`` onto it.

Flask is **WSGI (synchronous)**, so there is no async lifecycle here: background coroutines and the
transports websocket are out of scope — with ``wire="transports"`` the generated client still expects a
``{prefix}/ws`` endpoint + ``autosync``, which you supply with an async extension (flask-sock + a loop)
or, more simply, an async backend (aiohttp / Starlette). Static pages (``wire=None``) run as-is.
"""

from __future__ import annotations

from collections.abc import Sequence
from pathlib import Path
from typing import TYPE_CHECKING

from ..assets import AssetPolicy, asset_bundles
from ..bootstrap import AssetLayout, Lifecycle, Page, TreeMode, bootstrap, bundles_dir, tree_frame, tree_json
from ..packages import PackageRef, package_url_prefix, resolve_component_packages
from ..ui.design import Design, _select_page_design

if TYPE_CHECKING:  # annotations only — flask is imported inside the functions (not a spaday dependency)
    from flask import Flask


def mount(
    app: Flask,
    page: Page,
    *,
    prefix: str = "",
    routes: Sequence = (),
    js: str | Path | None = None,
    layout: AssetLayout | None = None,
    title: str = "spaday",
    packages: PackageRef | Sequence[PackageRef] = (),
    wire: str | None = None,
    ws: str = "/ws",
    tree: TreeMode = "json",
    reconnect: bool = False,
    scripts: Sequence[str] = (),
    stylesheets: Sequence[str] = (),
    styles: Sequence[str] = (),
    head: str = "",
    design: Design | str | None = None,
    lifecycle: Lifecycle | None = None,
    assets: AssetPolicy | None = None,
) -> Flask:
    """Add spaday's routes to an existing Flask ``app`` under ``prefix``. ``routes`` is a list of
    ``(rule, endpoint, view_func)`` tuples. Endpoints are keyed by ``prefix`` so several spaday pages can
    share one app. Returns ``app`` for chaining."""
    from flask import Response, send_from_directory

    asset_layout = layout or ("source" if js is not None else None)
    component_packages = resolve_component_packages(packages)
    page_design = _select_page_design(design, component_packages, page)
    asset_directory = Path(js) if js is not None else bundles_dir(asset_layout)
    bundles = asset_bundles(asset_directory, component_packages, prefix, assets, source=js is None and asset_directory == bundles_dir("source"))
    body = bootstrap(
        base=prefix,
        packages=component_packages,
        wire=wire,
        ws=ws,
        tree=tree,
        page=page,
        reconnect=reconnect,
        scripts=scripts,
        stylesheets=stylesheets,
        styles=styles,
        head=head,
        title=title,
        layout=asset_layout,
        design=page_design,
        lifecycle=lifecycle,
        _asset_urls={b.prefix: b.url for b in bundles},
    )
    js_dir = str(js) if js is not None else str(bundles_dir(asset_layout))
    key = prefix.strip("/").replace("/", "_") or "root"  # unique endpoint names per mount

    app.add_url_rule(f"{prefix}/", f"spaday_index_{key}", lambda: Response(body, mimetype="text/html"))
    if tree == "frame":
        app.add_url_rule(
            f"{prefix}/tree", f"spaday_tree_{key}", lambda: Response(tree_frame(page, design=page_design), mimetype="application/octet-stream")
        )
    elif tree == "json":
        app.add_url_rule(f"{prefix}/tree.json", f"spaday_tree_{key}", lambda: Response(tree_json(page, page_design), mimetype="application/json"))
    if assets is not None:
        from flask import request

        def handler(bundle):
            def respond(path):
                result = bundle.response(path, {k.lower(): v for k, v in request.headers.items()}, request.method)
                response = Response(result.body, status=result.status)
                response.headers.update(result.headers)
                return response

            return respond

        for index, bundle in enumerate(bundles):
            app.add_url_rule(bundle.prefix + "/<path:path>", f"spaday_asset_{key}_{index}", handler(bundle))
    else:
        app.add_url_rule(f"{prefix}/js/<path:path>", f"spaday_js_{key}", lambda path: send_from_directory(js_dir, path))
        for package in component_packages:
            package_dir = package.assets_dir
            package_key = package.name.replace("-", "_").replace(".", "_")
            app.add_url_rule(
                f"{package_url_prefix(package, prefix)}/<path:path>",
                f"spaday_component_{key}_{package_key}",
                lambda path, directory=package_dir: send_from_directory(directory, path),
            )
    for rule in routes:
        app.add_url_rule(*rule)
    return app


def serve(page: Page, *, import_name: str = "spaday", **opts) -> Flask:
    """Create a Flask app and :func:`mount` ``page`` onto it. ``import_name`` is Flask's (for resource
    resolution); all other keyword options are :func:`mount`'s."""
    from flask import Flask

    app = Flask(import_name)
    return mount(app, page, **opts)
